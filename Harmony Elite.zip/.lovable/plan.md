## Final Polish Plan

A focused pass to take the site from "ready" to "launch-quality." No new features — only refinements.

### 1. SEO & Social Sharing
- Verify `<title>` (~55 chars), meta description (~150 chars), and canonical on the home route in both languages.
- Confirm `og:title`, `og:description`, `og:image`, `twitter:card`, `twitter:image` are set; generate a branded 1200×630 OG image if missing.
- Ensure `lang` and `dir` attributes flip correctly on `<html>` for AR/EN (already wired — verify on SSR).
- Add `JSON-LD` structured data: `MedicalBusiness` / `Physiotherapy` with both branches (name, address, phone, geo, openingHours, sameAs).
- Re-check `sitemap.xml` and `robots.txt` are accurate.

### 2. Branding assets
- Ensure favicon, apple-touch-icon, and `manifest.json` (name, short_name, theme_color, background_color) all match the dark Harmony palette.

### 3. Bilingual polish
- Sweep all components for any hardcoded English strings still showing in AR mode (toasts, aria-labels, button titles, form validation).
- Verify Arabic numerals/dates render naturally in the booking flow and confirmation message.
- Re-check the RTL letter-spacing fix covers all blue eyebrow labels and badges.

### 4. Accessibility
- Add/verify `aria-label` on icon-only buttons (language toggle, close, call, WhatsApp, social icons).
- Ensure all interactive elements have visible focus states using the accent color.
- Confirm color contrast on muted text meets WCAG AA on the dark background.
- Add `prefers-reduced-motion` guard for the hero/scroll animations.

### 5. Performance
- Add `loading="lazy"` and `decoding="async"` to below-the-fold images (doctor portraits, location photos, review thumbnails).
- Ensure the hero image/video has `fetchpriority="high"` and a poster frame.
- Verify Google Fonts are preconnected and that only the weights actually used are loaded.

### 6. UX micro-refinements
- Smooth scroll behavior for in-page anchors (Services, Doctors, Locations, Booking).
- Sticky header shadow on scroll (subtle) for stronger separation.
- Booking form: trim phone input, prevent double-submit, scroll the success message into view on small screens.
- 404 page styled to match the brand (currently default boundary).

### 7. Final QA
- Run the SEO scan and resolve any remaining findings.
- Run the security scan to confirm no new issues.
- Manually walk through EN → AR toggle on every section at mobile (390px) and desktop (1280px).

---

### Out of scope
- New pages, services, or content sections.
- Backend schema or auth changes.
- Visual redesign — palette, typography, and layout stay as-is.

Want me to do the full pass, or trim to a specific subset (e.g. just SEO + accessibility)?