
CREATE TABLE IF NOT EXISTS public.doctors (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  title text,
  notification_email text,
  email_linked boolean NOT NULL DEFAULT false,
  email_linked_at timestamptz,
  email_linked_by uuid REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT doctors_email_format CHECK (
    notification_email IS NULL OR notification_email ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$'
  )
);
CREATE UNIQUE INDEX IF NOT EXISTS doctors_email_unique_ci
  ON public.doctors (LOWER(notification_email))
  WHERE notification_email IS NOT NULL;

GRANT SELECT, INSERT, UPDATE, DELETE ON public.doctors TO authenticated;
GRANT ALL ON public.doctors TO service_role;
ALTER TABLE public.doctors ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Staff manage doctors" ON public.doctors
  FOR ALL TO authenticated
  USING (public.is_staff(auth.uid()))
  WITH CHECK (public.is_staff(auth.uid()));
CREATE TRIGGER doctors_touch_updated_at BEFORE UPDATE ON public.doctors
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

ALTER TABLE public.bookings
  ADD COLUMN IF NOT EXISTS doctor_id uuid REFERENCES public.doctors(id) ON DELETE SET NULL;
CREATE INDEX IF NOT EXISTS bookings_doctor_id_idx ON public.bookings(doctor_id);

CREATE TABLE IF NOT EXISTS public.doctor_email_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  doctor_id uuid REFERENCES public.doctors(id) ON DELETE SET NULL,
  recipient_email text NOT NULL,
  booking_id uuid REFERENCES public.bookings(id) ON DELETE SET NULL,
  patient_id uuid REFERENCES public.patients(id) ON DELETE SET NULL,
  event_type text NOT NULL,
  status text NOT NULL DEFAULT 'queued',
  error_message text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS doctor_email_logs_doctor_idx ON public.doctor_email_logs(doctor_id);
CREATE INDEX IF NOT EXISTS doctor_email_logs_created_idx ON public.doctor_email_logs(created_at DESC);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.doctor_email_logs TO authenticated;
GRANT ALL ON public.doctor_email_logs TO service_role;
ALTER TABLE public.doctor_email_logs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Staff manage doctor email logs" ON public.doctor_email_logs
  FOR ALL TO authenticated
  USING (public.is_staff(auth.uid()))
  WITH CHECK (public.is_staff(auth.uid()));
