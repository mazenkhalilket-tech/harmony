ALTER TABLE public.bookings ADD COLUMN IF NOT EXISTS email text;
CREATE INDEX IF NOT EXISTS doctor_email_logs_booking_event_idx
  ON public.doctor_email_logs (booking_id, event_type)
  WHERE status IN ('queued','sent');