-- Restore EXECUTE on role-check helpers. These are SECURITY DEFINER and
-- are referenced by RLS policies (e.g. patients, bookings), so the
-- authenticated role MUST be able to call them or every policy denies.
GRANT EXECUTE ON FUNCTION public.is_staff(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated;