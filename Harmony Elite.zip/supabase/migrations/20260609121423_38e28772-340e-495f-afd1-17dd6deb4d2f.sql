CREATE UNIQUE INDEX IF NOT EXISTS bookings_unique_slot
  ON public.bookings (branch_id, booking_date, booking_time)
  WHERE status <> 'cancelled';

CREATE POLICY "Public can read taken slots"
  ON public.bookings FOR SELECT
  TO anon, authenticated
  USING (status <> 'cancelled');

GRANT SELECT ON public.bookings TO anon;