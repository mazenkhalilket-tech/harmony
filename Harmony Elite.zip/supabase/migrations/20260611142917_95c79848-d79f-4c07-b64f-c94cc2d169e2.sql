
-- 1) Stop exposing booking PII to the public (anon) role.
DROP POLICY IF EXISTS "Public can read taken slots" ON public.bookings;
REVOKE SELECT ON public.bookings FROM anon;

-- 2) Lock down Realtime channel subscriptions to staff only.
ALTER TABLE realtime.messages ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Staff can receive realtime" ON realtime.messages;
CREATE POLICY "Staff can receive realtime"
  ON realtime.messages FOR SELECT
  TO authenticated
  USING (public.is_staff(auth.uid()));

DROP POLICY IF EXISTS "Staff can send realtime" ON realtime.messages;
CREATE POLICY "Staff can send realtime"
  ON realtime.messages FOR INSERT
  TO authenticated
  WITH CHECK (public.is_staff(auth.uid()));

-- 3) Internal SECURITY DEFINER helpers should not be callable over the API.
REVOKE EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.is_staff(uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO service_role;
GRANT EXECUTE ON FUNCTION public.is_staff(uuid) TO service_role;
