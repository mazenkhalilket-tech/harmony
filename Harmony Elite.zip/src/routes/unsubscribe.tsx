import { createFileRoute, useSearch } from "@tanstack/react-router";
import { useEffect, useState } from "react";

export const Route = createFileRoute("/unsubscribe")({
  validateSearch: (s: Record<string, unknown>) => ({ token: typeof s.token === "string" ? s.token : "" }),
  head: () => ({
    meta: [
      { title: "Unsubscribe · Harmony Smart Clinic" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: Page,
});

function Page() {
  const { token } = useSearch({ from: "/unsubscribe" });
  const [state, setState] = useState<"checking" | "ready" | "done" | "invalid" | "used">("checking");
  const [email, setEmail] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!token) {
      setState("invalid");
      return;
    }
    fetch(`/email/unsubscribe?token=${encodeURIComponent(token)}`)
      .then((r) => r.json())
      .then((d) => {
        if (d?.used) setState("used");
        else if (d?.email) {
          setEmail(d.email);
          setState("ready");
        } else setState("invalid");
      })
      .catch(() => setState("invalid"));
  }, [token]);

  const confirm = async () => {
    setSubmitting(true);
    try {
      const r = await fetch("/email/unsubscribe", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token }),
      });
      if (r.ok) setState("done");
      else setState("invalid");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <main className="flex min-h-dvh items-center justify-center bg-midnight px-4 text-ice">
      <div className="glass-strong w-full max-w-md rounded-3xl p-8 text-center">
        <h1 className="font-display text-2xl">Email preferences</h1>
        {state === "checking" && <p className="mt-4 text-ice/60">Checking your link…</p>}
        {state === "invalid" && (
          <p className="mt-4 text-rose-300">This unsubscribe link is invalid or expired.</p>
        )}
        {state === "used" && (
          <p className="mt-4 text-ice/60">This email is already unsubscribed.</p>
        )}
        {state === "ready" && (
          <>
            <p className="mt-4 text-ice/70">
              Unsubscribe <span className="text-ice">{email}</span> from Harmony emails?
            </p>
            <button
              onClick={confirm}
              disabled={submitting}
              className="mt-6 rounded-full bg-accent px-6 py-2.5 text-sm font-medium text-accent-foreground disabled:opacity-60"
            >
              {submitting ? "Working…" : "Confirm unsubscribe"}
            </button>
          </>
        )}
        {state === "done" && (
          <p className="mt-4 text-emerald-300">You've been unsubscribed. Sorry to see you go.</p>
        )}
      </div>
    </main>
  );
}
