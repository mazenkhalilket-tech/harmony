import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { format } from "date-fns";
import { toast } from "sonner";
import { listBookings, updateBookingStatus, deleteBooking, deleteAllBookings } from "@/lib/bookings.functions";
import { supabase } from "@/integrations/supabase/client";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Trash2 } from "lucide-react";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";

export const Route = createFileRoute("/_authenticated/bookings/")({
  head: () => ({
    meta: [
      { title: "Bookings · Harmony Smart Clinic" },
      {
        name: "description",
        content:
          "Manage patient bookings and schedules across Harmony Physiotherapy Clinic branches.",
      },
      { name: "robots", content: "noindex, nofollow" },
      { property: "og:title", content: "Bookings · Harmony Smart Clinic" },
      {
        property: "og:description",
        content: "Internal staff dashboard for managing patient bookings.",
      },
    ],
  }),
  component: BookingsPage,
});

function formatTime12(t: string) {
  const [hStr, mStr] = t.split(":");
  const h = Number(hStr);
  const period = h >= 12 ? "PM" : "AM";
  const h12 = ((h + 11) % 12) + 1;
  return `${h12}:${mStr} ${period}`;
}

const STATUSES = ["pending", "confirmed", "completed", "cancelled"] as const;
type Status = (typeof STATUSES)[number];

const statusStyles: Record<Status, string> = {
  pending: "bg-amber-500/15 text-amber-300 border-amber-500/30",
  confirmed: "bg-emerald-500/15 text-emerald-300 border-emerald-500/30",
  completed: "bg-sky-500/15 text-sky-300 border-sky-500/30",
  cancelled: "bg-rose-500/15 text-rose-300 border-rose-500/30",
};

function BookingsPage() {
  const listFn = useServerFn(listBookings);
  const updateFn = useServerFn(updateBookingStatus);
  const deleteFn = useServerFn(deleteBooking);
  const clearAllFn = useServerFn(deleteAllBookings);
  const qc = useQueryClient();

  const { data: bookings = [], isLoading } = useQuery({
    queryKey: ["bookings"],
    queryFn: () => listFn(),
  });

  useEffect(() => {
    const ch = supabase
      .channel("bookings-dashboard")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "bookings" },
        () => qc.invalidateQueries({ queryKey: ["bookings"] }),
      )
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [qc]);

  const update = useMutation({
    mutationFn: updateFn,
    onSuccess: () => {
      toast.success("Updated");
      qc.invalidateQueries({ queryKey: ["bookings"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const remove = useMutation({
    mutationFn: deleteFn,
    onSuccess: () => {
      toast.success("Booking removed");
      qc.invalidateQueries({ queryKey: ["bookings"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const clearAll = useMutation({
    mutationFn: clearAllFn,
    onSuccess: () => {
      toast.success("All bookings cleared");
      qc.invalidateQueries({ queryKey: ["bookings"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const pending = bookings.filter((b: any) => b.status === "pending").length;

  return (
    <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 sm:py-10">
      <div className="mb-8 grid grid-cols-[minmax(0,1fr)_auto] items-start gap-3 sm:flex sm:items-end sm:justify-between">
        <div className="min-w-0">
          <p className="text-xs uppercase tracking-[0.25em] text-accent">Reception</p>
          <h1 className="mt-1 text-2xl font-medium sm:text-3xl">Bookings</h1>
          <p className="mt-1 text-sm text-ice/50">
            {pending} pending · {bookings.length} total · live sync
          </p>
        </div>
        <div className="flex shrink-0 items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => qc.invalidateQueries({ queryKey: ["bookings"] })}>
            Refresh
          </Button>
          {bookings.length > 0 && (
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="outline" size="sm" className="border-rose-500/40 text-rose-300 hover:bg-rose-500/10 hover:text-rose-200">
                  Clear all
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Clear all bookings?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This permanently removes all {bookings.length} bookings and cannot be undone.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={() => clearAll.mutate({})}>Clear all</AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          )}
        </div>
      </div>

      {isLoading ? (
        <p className="text-ice/50">Loading…</p>
      ) : bookings.length === 0 ? (
        <div className="glass-strong rounded-2xl p-10 text-center text-ice/60">
          No bookings yet. New customer bookings appear here in real time.
        </div>
      ) : (
        <div className="glass-strong overflow-hidden rounded-2xl">
          <div className="hidden grid-cols-[1.4fr_1fr_1.4fr_1fr_1.2fr_1fr] gap-3 border-b border-white/5 px-5 py-3 text-[10px] uppercase tracking-[0.2em] text-ice/40 sm:grid">
            <span>Patient</span><span>When</span><span>Service</span>
            <span>Branch</span><span>Phone</span><span>Status</span>
          </div>
          {bookings.map((b: any) => (
            <div
              key={b.id}
              className="grid grid-cols-1 gap-2 border-b border-white/5 px-5 py-4 last:border-b-0 sm:grid-cols-[1.4fr_1fr_1.4fr_1fr_1.2fr_1fr] sm:gap-3"
            >
              <div>
                <p className="font-medium text-ice">{b.full_name}</p>
                <p className="text-xs text-ice/40">{b.gender}</p>
              </div>
              <div className="text-sm text-ice/80">
                {format(new Date(b.booking_date), "EEE, MMM d")}
                <p className="text-xs text-ice/40">{formatTime12(b.booking_time)}</p>
              </div>
              <div className="text-sm text-ice/80">{b.service}</div>
              <div className="text-sm text-ice/70">{b.branch_label}</div>
              <div className="text-sm text-ice/70">
                <a href={`tel:${b.phone}`} className="hover:text-accent">{b.phone}</a>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className={statusStyles[b.status as Status]}>
                  {b.status}
                </Badge>
                <Select
                  value={b.status}
                  onValueChange={(v) => update.mutate({ data: { id: b.id, status: v as Status } })}
                >
                  <SelectTrigger className="h-7 w-[110px] text-xs"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {STATUSES.map((s) => (
                      <SelectItem key={s} value={s}>{s}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <button
                      aria-label="Remove booking"
                      className="rounded-full p-1.5 text-ice/40 transition hover:bg-rose-500/10 hover:text-rose-300"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Remove this booking?</AlertDialogTitle>
                      <AlertDialogDescription>
                        {b.full_name} — {format(new Date(b.booking_date), "EEE, MMM d")} · {formatTime12(b.booking_time)}.
                        This frees the slot and cannot be undone.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction onClick={() => remove.mutate({ data: { id: b.id } })}>
                        Remove
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            </div>
          ))}
        </div>
      )}
    </main>
  );
}
