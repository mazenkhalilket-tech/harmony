import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { format } from "date-fns";
import { CheckCircle2, Link2, Link2Off, Mail, Plus, Send, Stethoscope, Trash2, UserCog, XCircle } from "lucide-react";
import {
  clearAllDoctorEmailLogs,
  createDoctor,
  deleteDoctor,
  deleteDoctorEmailLog,
  getReceptionistEmail,
  linkDoctorEmail,
  linkReceptionistEmail,
  listDoctors,
  listRecentDoctorEmailLogs,
  sendDoctorTest,
  sendReceptionistTest,
  unlinkDoctorEmail,
  unlinkReceptionistEmail,
} from "@/lib/doctors.functions";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

export const Route = createFileRoute("/_authenticated/doctors/")({
  head: () => ({
    meta: [
      { title: "Doctors · Harmony Smart Clinic" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: DoctorsPage,
});

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function DoctorsPage() {
  const listFn = useServerFn(listDoctors);
  const createFn = useServerFn(createDoctor);
  const linkFn = useServerFn(linkDoctorEmail);
  const unlinkFn = useServerFn(unlinkDoctorEmail);
  const deleteFn = useServerFn(deleteDoctor);
  const logsFn = useServerFn(listRecentDoctorEmailLogs);
  const deleteLogFn = useServerFn(deleteDoctorEmailLog);
  const clearLogsFn = useServerFn(clearAllDoctorEmailLogs);
  const testFn = useServerFn(sendDoctorTest);
  const getReceptionistFn = useServerFn(getReceptionistEmail);
  const linkReceptionistFn = useServerFn(linkReceptionistEmail);
  const unlinkReceptionistFn = useServerFn(unlinkReceptionistEmail);
  const testReceptionistFn = useServerFn(sendReceptionistTest);
  const qc = useQueryClient();

  const { data: doctors = [], isLoading } = useQuery({
    queryKey: ["doctors"],
    queryFn: () => listFn(),
  });
  const { data: logs = [] } = useQuery({
    queryKey: ["doctor-email-logs"],
    queryFn: () => logsFn(),
    refetchInterval: 10_000,
  });

  const create = useMutation({
    mutationFn: createFn,
    onSuccess: () => {
      toast.success("Doctor added");
      qc.invalidateQueries({ queryKey: ["doctors"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const link = useMutation({
    mutationFn: linkFn,
    onSuccess: () => {
      toast.success("Email linked");
      qc.invalidateQueries({ queryKey: ["doctors"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const unlink = useMutation({
    mutationFn: unlinkFn,
    onSuccess: () => {
      toast.success("Email unlinked");
      qc.invalidateQueries({ queryKey: ["doctors"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const remove = useMutation({
    mutationFn: deleteFn,
    onSuccess: () => {
      toast.success("Doctor removed");
      qc.invalidateQueries({ queryKey: ["doctors"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const test = useMutation({
    mutationFn: testFn,
    onSuccess: () => {
      toast.success("Test email submitted");
      qc.invalidateQueries({ queryKey: ["doctor-email-logs"] });
    },
    onError: (e: Error) => toast.error(e.message || "Could not send test email."),
  });

  const deleteLog = useMutation({
    mutationFn: deleteLogFn,
    onSuccess: () => {
      toast.success("Email log deleted");
      qc.invalidateQueries({ queryKey: ["doctor-email-logs"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const clearLogs = useMutation({
    mutationFn: clearLogsFn,
    onSuccess: () => {
      toast.success("All email logs cleared");
      qc.invalidateQueries({ queryKey: ["doctor-email-logs"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const { data: reception } = useQuery({
    queryKey: ["receptionist-email"],
    queryFn: () => getReceptionistFn(),
  });

  const linkReceptionist = useMutation({
    mutationFn: linkReceptionistFn,
    onSuccess: () => {
      toast.success("Receptionist email linked");
      qc.invalidateQueries({ queryKey: ["receptionist-email"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const unlinkReceptionist = useMutation({
    mutationFn: unlinkReceptionistFn,
    onSuccess: () => {
      toast.success("Receptionist email unlinked");
      qc.invalidateQueries({ queryKey: ["receptionist-email"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const testReceptionist = useMutation({
    mutationFn: testReceptionistFn,
    onSuccess: () => {
      toast.success("Test email submitted");
      qc.invalidateQueries({ queryKey: ["doctor-email-logs"] });
    },
    onError: (e: Error) => toast.error(e.message || "Could not send test email."),
  });


  return (
    <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 sm:py-10">
      <div className="mb-8 flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="text-xs uppercase tracking-[0.25em] text-accent">Staff portal</p>
          <h1 className="mt-1 text-2xl font-medium sm:text-3xl">Doctors & email links</h1>
          <p className="mt-1 text-sm text-ice/50">
            Link a doctor's email to auto-send new booking and patient submissions.
          </p>
        </div>
        <AddDoctorButton onAdd={(v) => create.mutate({ data: v })} pending={create.isPending} />
      </div>

      <ReceptionistCard
        email={reception?.receptionist_email ?? null}
        onLink={(email) => linkReceptionist.mutateAsync({ data: { email } })}
        onUnlink={() => unlinkReceptionist.mutate(undefined)}
        onTest={() => testReceptionist.mutate(undefined)}
        testing={testReceptionist.isPending}
      />

      {isLoading ? (
        <p className="text-ice/50">Loading…</p>
      ) : doctors.length === 0 ? (
        <div className="glass-strong rounded-2xl p-10 text-center text-ice/60">
          No doctors yet. Add one to start linking notification emails.
        </div>
      ) : (
        <div className="glass-strong overflow-hidden rounded-2xl">
          {doctors.map((d: any) => (
            <DoctorRow
              key={d.id}
              doctor={d}
              onLink={(email) => link.mutateAsync({ data: { id: d.id, email } })}
              onUnlink={() => unlink.mutate({ data: { id: d.id } })}
              onDelete={() => remove.mutate({ data: { id: d.id } })}
              onTest={() => test.mutate({ data: { id: d.id } })}
              testing={test.isPending && (test.variables as { data?: { id?: string } } | undefined)?.data?.id === d.id}
            />
          ))}
        </div>
      )}

      <section className="mt-10">
        <div className="mb-3 flex items-center justify-between gap-3">
          <h2 className="text-sm font-medium uppercase tracking-[0.2em] text-ice/60">
            Email logs
          </h2>
          {logs.length > 0 && (
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button size="sm" variant="outline" className="border-rose-500/30 text-rose-200 hover:bg-rose-500/10">
                  <Trash2 className="me-1.5 h-3.5 w-3.5" />
                  Clear all
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Clear all email logs?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This permanently removes every doctor email log entry. This action cannot be undone.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={() => clearLogs.mutate(undefined)}>
                    Clear all
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          )}
        </div>
        {logs.length === 0 ? (
          <p className="text-sm text-ice/40">No emails sent yet.</p>

        ) : (
          <div className="glass-strong overflow-hidden rounded-2xl">
            {logs.slice(0, 30).map((l: any) => (
              <div
                key={l.id}
                className="flex flex-wrap items-center gap-3 border-b border-white/5 px-5 py-3 text-sm last:border-b-0"
              >
                <Mail className="h-3.5 w-3.5 text-ice/40" />
                <span className="text-ice/80">{l.recipient_email}</span>
                <span className="text-xs text-ice/40">{l.event_type}</span>
                <Badge
                  variant="outline"
                  className={
                    l.status === "queued" || l.status === "sent"
                      ? "border-emerald-500/30 bg-emerald-500/10 text-emerald-300"
                      : l.status === "suppressed"
                      ? "border-amber-500/30 bg-amber-500/10 text-amber-300"
                      : "border-rose-500/30 bg-rose-500/10 text-rose-300"
                  }
                >
                  {l.status}
                </Badge>
                {l.error_message ? (
                  <span className="basis-full text-xs text-rose-300/80">{l.error_message}</span>
                ) : null}
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <button
                      aria-label="Delete email log"
                      className="rounded-full p-1.5 text-ice/40 transition hover:bg-rose-500/10 hover:text-rose-300"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Delete this email log?</AlertDialogTitle>
                      <AlertDialogDescription>
                        This removes the selected doctor email log entry from the Staff Portal.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction onClick={() => deleteLog.mutate({ data: { id: l.id } })}>
                        Delete
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
                <span className="ms-auto text-xs text-ice/40">
                  {format(new Date(l.created_at), "MMM d, HH:mm")}
                </span>
              </div>
            ))}
          </div>
        )}
      </section>
    </main>
  );
}

function DoctorRow({
  doctor,
  onLink,
  onUnlink,
  onDelete,
  onTest,
  testing,
}: {
  doctor: any;
  onLink: (email: string) => Promise<unknown>;
  onUnlink: () => void;
  onDelete: () => void;
  onTest: () => void;
  testing: boolean;
}) {
  const [open, setOpen] = useState(false);
  const [email, setEmail] = useState(doctor.notification_email ?? "");
  const [submitting, setSubmitting] = useState(false);

  const linked = doctor.email_linked && !!doctor.notification_email;

  const handleLink = async () => {
    if (!EMAIL_RE.test(email.trim())) {
      toast.error("Enter a valid email address.");
      return;
    }
    setSubmitting(true);
    try {
      await onLink(email.trim());
      setOpen(false);
    } catch {
      /* toast already shown */
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="flex flex-wrap items-center gap-4 border-b border-white/5 px-5 py-4 last:border-b-0">
      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-accent/10 text-accent">
        <Stethoscope className="h-4 w-4" />
      </div>
      <div className="min-w-0 flex-1">
        <p className="font-medium text-ice">
          {doctor.title ? `${doctor.title} ` : ""}
          {doctor.name}
        </p>
        <p className="truncate text-xs text-ice/50">
          {doctor.notification_email ?? "No email linked"}
        </p>
      </div>

      {linked ? (
        <Badge variant="outline" className="border-emerald-500/30 bg-emerald-500/10 text-emerald-300">
          <CheckCircle2 className="me-1 h-3 w-3" /> Linked
        </Badge>
      ) : (
        <Badge variant="outline" className="border-rose-500/30 bg-rose-500/10 text-rose-300">
          <XCircle className="me-1 h-3 w-3" /> Not linked
        </Badge>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogTrigger asChild>
          <Button size="sm" variant="outline">
            <Link2 className="me-1.5 h-3.5 w-3.5" />
            {linked ? "Update email" : "Link email"}
          </Button>
        </DialogTrigger>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Link email to {doctor.name}</DialogTitle>
            <DialogDescription>
              All new bookings linked to this doctor will be sent to this address.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2">
            <Label>Doctor email</Label>
            <Input
              type="email"
              autoFocus
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="doctor@example.com"
            />
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleLink} disabled={submitting}>
              {submitting ? "Linking…" : "Verify & link"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {linked && (
        <Button size="sm" variant="outline" onClick={onTest} disabled={testing}>
          <Send className="me-1.5 h-3.5 w-3.5" />
          {testing ? "Sending…" : "Send test"}
        </Button>
      )}

      {linked && (
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button size="sm" variant="outline" className="border-rose-500/30 text-rose-200 hover:bg-rose-500/10">
              <Link2Off className="me-1.5 h-3.5 w-3.5" />
              Unlink
            </Button>

          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Unlink email?</AlertDialogTitle>
              <AlertDialogDescription>
                This stops all future automatic emails to {doctor.notification_email}.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={onUnlink}>Unlink</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      )}

      <AlertDialog>
        <AlertDialogTrigger asChild>
          <button
            aria-label="Remove doctor"
            className="rounded-full p-1.5 text-ice/40 transition hover:bg-rose-500/10 hover:text-rose-300"
          >
            <Trash2 className="h-3.5 w-3.5" />
          </button>
        </AlertDialogTrigger>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Remove this doctor?</AlertDialogTitle>
            <AlertDialogDescription>
              {doctor.name} will be removed and any future bookings will no longer reference them.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={onDelete}>Remove</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function AddDoctorButton({
  onAdd,
  pending,
}: {
  onAdd: (v: { name: string; title?: string }) => void;
  pending: boolean;
}) {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [title, setTitle] = useState("");

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>
          <Plus className="me-1.5 h-4 w-4" /> Add doctor
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Add a doctor</DialogTitle>
          <DialogDescription>You can link the notification email after creating the profile.</DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div className="space-y-2">
            <Label>Title (optional)</Label>
            <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Dr." />
          </div>
          <div className="space-y-2">
            <Label>Full name</Label>
            <Input autoFocus value={name} onChange={(e) => setName(e.target.value)} placeholder="Amr Eltourky" />
          </div>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={() => setOpen(false)}>
            Cancel
          </Button>
          <Button
            disabled={pending || name.trim().length < 2}
            onClick={() => {
              onAdd({ name: name.trim(), title: title.trim() || undefined });
              setOpen(false);
              setName("");
              setTitle("");
            }}
          >
            {pending ? "Adding…" : "Add doctor"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function ReceptionistCard({
  email,
  onLink,
  onUnlink,
  onTest,
  testing,
}: {
  email: string | null;
  onLink: (email: string) => Promise<unknown>;
  onUnlink: () => void;
  onTest: () => void;
  testing: boolean;
}) {
  const [open, setOpen] = useState(false);
  const [value, setValue] = useState(email ?? "");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    setValue(email ?? "");
  }, [email]);

  const linked = !!email;

  const handleLink = async () => {
    if (!EMAIL_RE.test(value.trim())) {
      toast.error("Enter a valid email address.");
      return;
    }
    setSubmitting(true);
    try {
      await onLink(value.trim());
      setOpen(false);
    } catch {
      /* toast already shown */
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="glass-strong mb-6 flex flex-wrap items-center gap-4 rounded-2xl px-5 py-4">
      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-accent/10 text-accent">
        <UserCog className="h-4 w-4" />
      </div>
      <div className="min-w-0 flex-1">
        <p className="font-medium text-ice">Receptionist</p>
        <p className="truncate text-xs text-ice/50">
          {email ?? "No email linked"} · Receives copies of every booking notification
        </p>
      </div>

      {linked ? (
        <Badge variant="outline" className="border-emerald-500/30 bg-emerald-500/10 text-emerald-300">
          <CheckCircle2 className="me-1 h-3 w-3" /> Linked
        </Badge>
      ) : (
        <Badge variant="outline" className="border-rose-500/30 bg-rose-500/10 text-rose-300">
          <XCircle className="me-1 h-3 w-3" /> Not linked
        </Badge>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogTrigger asChild>
          <Button size="sm" variant="outline">
            <Link2 className="me-1.5 h-3.5 w-3.5" />
            {linked ? "Update email" : "Link email"}
          </Button>
        </DialogTrigger>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Link receptionist email</DialogTitle>
            <DialogDescription>
              All bookings (from every doctor) will be sent as a copy to this address.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2">
            <Label>Receptionist email</Label>
            <Input
              type="email"
              autoFocus
              value={value}
              onChange={(e) => setValue(e.target.value)}
              placeholder="reception@example.com"
            />
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleLink} disabled={submitting}>
              {submitting ? "Linking…" : "Verify & link"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {linked && (
        <Button size="sm" variant="outline" onClick={onTest} disabled={testing}>
          <Send className="me-1.5 h-3.5 w-3.5" />
          {testing ? "Sending…" : "Send test"}
        </Button>
      )}

      {linked && (
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button size="sm" variant="outline" className="border-rose-500/30 text-rose-200 hover:bg-rose-500/10">
              <Link2Off className="me-1.5 h-3.5 w-3.5" />
              Unlink
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Unlink receptionist email?</AlertDialogTitle>
              <AlertDialogDescription>
                This stops future booking-copy emails to {email}.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={onUnlink}>Unlink</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      )}
    </div>
  );
}
