import { createFileRoute, Outlet, redirect, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { CalendarCheck, LogOut, ShieldCheck, Stethoscope, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { verifyStaffSecondary } from "@/lib/staff-gate.functions";



export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async () => {
    const { data, error } = await supabase.auth.getUser();
    if (error || !data.user) throw redirect({ to: "/auth" });
    return { user: data.user };
  },
  component: StaffShell,
});

function StaffShell() {
  const nav = useNavigate();
  // In-memory only — sessionStorage was client-controlled and trivially
  // bypassable from DevTools. Server-side staff role checks are the real gate.
  const [verified, setVerified] = useState<boolean>(false);

  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((event) => {
      if (event === "SIGNED_OUT") {
        setVerified(false);
        nav({ to: "/auth", replace: true });
      }
    });
    return () => sub.subscription.unsubscribe();
  }, [nav]);

  return (
    <div className="min-h-screen bg-midnight text-ice">
      <header className="border-b border-white/5 bg-midnight/80 backdrop-blur-md">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
          <div className="flex items-center gap-6">
            <Link to="/" className="text-sm font-medium tracking-wide text-ice">
              Harmony · Smart Clinic
            </Link>
            <nav className="hidden gap-1 sm:flex">
              <Link to="/bookings" className="rounded-full px-3 py-1.5 text-xs uppercase tracking-[0.18em] text-ice/60 hover:bg-white/5 hover:text-ice [&.active]:bg-accent/15 [&.active]:text-ice">
                <CalendarCheck className="mr-1.5 inline h-3.5 w-3.5" />
                Bookings
              </Link>
              <Link to="/patients" className="rounded-full px-3 py-1.5 text-xs uppercase tracking-[0.18em] text-ice/60 hover:bg-white/5 hover:text-ice [&.active]:bg-accent/15 [&.active]:text-ice">
                <Users className="mr-1.5 inline h-3.5 w-3.5" />
                Patients
              </Link>
              <Link to="/doctors" className="rounded-full px-3 py-1.5 text-xs uppercase tracking-[0.18em] text-ice/60 hover:bg-white/5 hover:text-ice [&.active]:bg-accent/15 [&.active]:text-ice">
                <Stethoscope className="mr-1.5 inline h-3.5 w-3.5" />
                Doctors
              </Link>
            </nav>
          </div>
          <Button variant="ghost" size="sm" onClick={async () => { await supabase.auth.signOut(); }}>
            <LogOut className="mr-1.5 h-3.5 w-3.5" /> Sign out
          </Button>
        </div>
      </header>
      {verified ? <Outlet /> : <StaffGate onVerified={() => setVerified(true)} />}
    </div>
  );
}

function StaffGate({ onVerified }: { onVerified: () => void }) {
  const verifyFn = useServerFn(verifyStaffSecondary);
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      await verifyFn({ data: { password } });
      onVerified();
    } catch (err: any) {
      setError(err?.message ?? "Verification failed.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="flex min-h-[calc(100vh-64px)] items-center justify-center px-4 py-12">
      <form
        onSubmit={submit}
        className="glass-strong w-full max-w-md space-y-5 rounded-3xl p-8"
      >
        <div className="flex items-center gap-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-full bg-accent/15 text-accent">
            <ShieldCheck className="h-5 w-5" />
          </span>
          <div>
            <p className="text-xs uppercase tracking-[0.25em] text-accent">Secondary check</p>
            <h1 className="text-xl font-medium text-ice">Staff verification</h1>
          </div>
        </div>
        <p className="text-sm text-ice/60">
          Enter the staff access code to continue. This stays active until you sign out.
        </p>
        <div>
          <Label>Staff access code</Label>
          <Input
            type="password"
            autoFocus
            autoComplete="off"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        {error && (
          <p className="rounded-lg border border-rose-500/30 bg-rose-500/10 px-3 py-2 text-xs text-rose-200">
            {error}
          </p>
        )}
        <Button type="submit" className="w-full" disabled={loading}>
          {loading ? "Verifying…" : "Unlock staff portal"}
        </Button>
      </form>
    </main>
  );
}
