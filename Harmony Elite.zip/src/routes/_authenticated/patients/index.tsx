import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Plus, Trash2 } from "lucide-react";
import { createPatient, deleteAllPatients, deletePatient, listPatients } from "@/lib/anatomy/procedures.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import { format } from "date-fns";

export const Route = createFileRoute("/_authenticated/patients/")({
  head: () => ({
    meta: [
      { title: "Patients · Harmony Smart Clinic" },
      {
        name: "description",
        content:
          "Manage patient files and clinical records for Harmony Physiotherapy Clinic.",
      },
      { name: "robots", content: "noindex, nofollow" },
      { property: "og:title", content: "Patients · Harmony Smart Clinic" },
      {
        property: "og:description",
        content: "Internal staff dashboard for patient file management.",
      },
    ],
  }),
  component: PatientsPage,
});

function PatientsPage() {
  const listFn = useServerFn(listPatients);
  const createFn = useServerFn(createPatient);
  const deleteFn = useServerFn(deletePatient);
  const clearAllFn = useServerFn(deleteAllPatients);
  const qc = useQueryClient();

  const { data: patients = [], isLoading } = useQuery({
    queryKey: ["patients"],
    queryFn: () => listFn(),
  });

  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ full_name: "", sex: "" as "" | "male" | "female", phone: "", primary_complaint: "" });

  const create = useMutation({
    mutationFn: createFn,
    onSuccess: () => {
      toast.success("Patient added");
      qc.invalidateQueries({ queryKey: ["patients"] });
      setOpen(false);
      setForm({ full_name: "", sex: "", phone: "", primary_complaint: "" });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const remove = useMutation({
    mutationFn: deleteFn,
    onSuccess: () => {
      toast.success("Patient removed");
      qc.invalidateQueries({ queryKey: ["patients"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const clearAll = useMutation({
    mutationFn: clearAllFn,
    onSuccess: () => {
      toast.success("All patients cleared");
      qc.invalidateQueries({ queryKey: ["patients"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 sm:py-10">
      <div className="mb-8 grid grid-cols-[minmax(0,1fr)_auto] items-start gap-3 sm:flex sm:items-center sm:justify-between">
        <div className="min-w-0">
          <p className="text-xs uppercase tracking-[0.25em] text-accent">Patient Files</p>
          <h1 className="mt-1 text-2xl font-medium sm:text-3xl">All Patients</h1>
        </div>
        <div className="flex shrink-0 items-center gap-2">
          {patients.length > 0 && (
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="outline" size="sm" className="border-rose-500/40 text-rose-300 hover:bg-rose-500/10 hover:text-rose-200">
                  Clear all
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Clear all patients?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This permanently deletes all {patients.length} patient files and linked records.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={() => clearAll.mutate({})}>Clear all</AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          )}
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button size="sm"><Plus className="mr-2 h-4 w-4" /> New Patient</Button>
            </DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>New Patient</DialogTitle></DialogHeader>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                create.mutate({
                  data: {
                    full_name: form.full_name,
                    sex: form.sex || undefined,
                    phone: form.phone || undefined,
                    primary_complaint: form.primary_complaint || undefined,
                  },
                });
              }}
              className="space-y-4"
            >
              <div>
                <Label>Full name</Label>
                <Input required value={form.full_name}
                  onChange={(e) => setForm({ ...form, full_name: e.target.value })} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>Sex</Label>
                  <Select value={form.sex} onValueChange={(v: "male" | "female") => setForm({ ...form, sex: v })}>
                    <SelectTrigger><SelectValue placeholder="—" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male">Male</SelectItem>
                      <SelectItem value="female">Female</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Phone</Label>
                  <Input value={form.phone}
                    onChange={(e) => setForm({ ...form, phone: e.target.value })} />
                </div>
              </div>
              <div>
                <Label>Primary complaint</Label>
                <Input value={form.primary_complaint}
                  onChange={(e) => setForm({ ...form, primary_complaint: e.target.value })} />
              </div>
              <Button type="submit" disabled={create.isPending} className="w-full">
                {create.isPending ? "Saving…" : "Create"}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
        </div>
      </div>

      {isLoading ? (
        <p className="text-ice/50">Loading…</p>
      ) : patients.length === 0 ? (
        <div className="glass-strong rounded-2xl p-10 text-center">
          <p className="text-ice/60">No patients yet. Add your first patient above.</p>
        </div>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {patients.map((p) => (
            <div key={p.id} className="glass relative rounded-2xl p-5">
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <button
                    aria-label="Remove patient"
                    className="absolute right-3 top-3 rounded-full p-1.5 text-ice/40 transition hover:bg-rose-500/10 hover:text-rose-300"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Remove {p.full_name}?</AlertDialogTitle>
                    <AlertDialogDescription>
                      This permanently deletes the patient file and all linked records.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={() => remove.mutate({ data: { id: p.id } })}>
                      Remove
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
              <h3 className="pr-8 font-medium text-ice">{p.full_name}</h3>
              <p className="mt-1 text-xs text-ice/50">
                {p.sex ?? "—"} · {p.phone ?? "no phone"}
              </p>
              {p.primary_complaint && (
                <p className="mt-2 line-clamp-2 text-sm text-ice/70">{p.primary_complaint}</p>
              )}
              <p className="mt-3 text-[10px] uppercase tracking-[0.2em] text-ice/40">
                Added {format(new Date(p.created_at), "MMM d, yyyy")}
              </p>
            </div>
          ))}
        </div>
      )}
    </main>
  );
}
