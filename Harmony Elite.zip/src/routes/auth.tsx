import { Link, Outlet, createFileRoute, useNavigate, useRouterState } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Eye, EyeOff } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { PasswordStrength } from "@/components/auth/password-strength";
import { getAuthErrorMessage, isStrongPassword } from "@/lib/auth";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Staff Portal · Harmony Physiotherapy" },
      {
        name: "description",
        content:
          "Secure staff portal sign-in and registration for Harmony Physiotherapy Clinic clinicians and administrators.",
      },
      { name: "robots", content: "noindex, nofollow" },
      { property: "og:title", content: "Staff Portal · Harmony Physiotherapy" },
      {
        property: "og:description",
        content: "Access the Harmony Physiotherapy Clinic staff portal.",
      },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const nav = useNavigate();
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [loading, setLoading] = useState(false);
  const [cooldown, setCooldown] = useState(0);
  const [pendingConfirmEmail, setPendingConfirmEmail] = useState<string | null>(null);
  const [showPassword, setShowPassword] = useState(false);

  const resendDisabled = useMemo(() => cooldown > 0 || loading || !pendingConfirmEmail, [cooldown, loading, pendingConfirmEmail]);

  useEffect(() => {
    if (cooldown <= 0) return;
    const timer = window.setTimeout(() => setCooldown((value) => Math.max(0, value - 1)), 1000);
    return () => window.clearTimeout(timer);
  }, [cooldown]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (mode === "signup") {
        if (!isStrongPassword(password)) {
          throw new Error("Please choose a stronger password.");
        }

        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: `${window.location.origin}/auth/verify`,
            data: { full_name: fullName },
          },
        });
        if (error) throw error;
        // If user already exists, Supabase returns an obfuscated identity with no new email
        const identities = data.user?.identities ?? [];
        if (identities.length === 0) {
          toast.error("An account with this email already exists. Try signing in or resetting your password.");
          setMode("signin");
        } else {
          setPendingConfirmEmail(email);
          setCooldown(60);
          toast.success("Account created. Check your email to verify your account.");
          nav({ to: "/auth/verify", search: { email } });
        }
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        toast.success("Welcome back");
        nav({ to: "/bookings" });
      }
    } catch (e: any) {
      toast.error(getAuthErrorMessage(e));
    } finally {
      setLoading(false);
    }
  };

  const resend = async () => {
    if (!pendingConfirmEmail) return;
    setLoading(true);
    try {
      const { error } = await supabase.auth.resend({
        type: "signup",
        email: pendingConfirmEmail,
        options: { emailRedirectTo: `${window.location.origin}/auth/verify` },
      });
      if (error) throw error;
      setCooldown(60);
      toast.success("Confirmation email re-sent. Check your inbox and spam folder.");
    } catch (e: any) {
      toast.error(getAuthErrorMessage(e));
    } finally {
      setLoading(false);
    }
  };

  if (pathname !== "/auth") {
    return <Outlet />;
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-midnight px-4 py-12">
      <form onSubmit={submit} className="glass-strong w-full max-w-md space-y-5 rounded-3xl p-8">
        <div>
          <p className="text-xs uppercase tracking-[0.25em] text-accent">Staff Portal</p>
          <h1 className="mt-2 text-3xl font-medium text-ice">
            {mode === "signin" ? "Sign in" : "Create account"}
          </h1>
          <p className="mt-2 text-xs text-ice/50">
            {mode === "signin"
              ? "Staff access only. New members can create an account below."
              : "Register a new staff account. Access to the portal still requires staff verification."}
          </p>
        </div>
        {mode === "signup" && (
          <div>
            <Label htmlFor="auth-full-name">Full name</Label>
            <Input id="auth-full-name" value={fullName} onChange={(e) => setFullName(e.target.value)} required />
          </div>
        )}
        <div>
          <Label htmlFor="auth-email">Email</Label>
          <Input id="auth-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
        </div>
        <div>
          <Label htmlFor="auth-password">Password</Label>
          <div className="relative">
            <Input
              id="auth-password"
              type={showPassword ? "text" : "password"}
              minLength={6}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              className="pr-10"
            />
            <button
              type="button"
              onClick={() => setShowPassword((v) => !v)}
              aria-label={showPassword ? "Hide password" : "Show password"}
              className="absolute inset-y-0 right-0 flex items-center px-3 text-ice/60 transition hover:text-ice"
            >
              {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
        </div>
        {mode === "signup" && <PasswordStrength password={password} />}
        <Button type="submit" className="w-full" disabled={loading}>
          {loading ? (mode === "signin" ? "Signing in…" : "Creating account…") : mode === "signin" ? "Sign in" : "Create account"}
        </Button>
        {mode === "signin" && (
          <Link to="/auth/forgot-password" className="block text-center text-xs text-ice/60 transition hover:text-accent">
            Forgot password?
          </Link>
        )}
        {mode === "signup" && pendingConfirmEmail && (
          <div className="rounded-xl border border-accent/30 bg-accent/5 p-3 text-xs text-ice/70">
            <p>
              Didn't get the email at <span className="text-ice">{pendingConfirmEmail}</span>? Check your spam folder or
              resend it.
            </p>
            <Button
              type="button"
              variant="outline"
              size="sm"
              className="mt-2 w-full"
              onClick={resend}
              disabled={resendDisabled}
            >
              {loading ? "Sending…" : cooldown > 0 ? `Resend in ${cooldown}s` : "Resend confirmation email"}
            </Button>
          </div>
        )}
        <button
          type="button"
          onClick={() => setMode(mode === "signin" ? "signup" : "signin")}
          className="block w-full text-center text-xs text-accent hover:text-ice"
        >
          {mode === "signin"
            ? "New member? Create a staff account"
            : "Already have an account? Sign in"}
        </button>
      </form>
    </main>
  );
}
