import { Link, createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { MailCheck } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { getAuthErrorMessage } from "@/lib/auth";
import { toast } from "sonner";

export const Route = createFileRoute("/auth/verify")({
  validateSearch: (search: Record<string, unknown>) => ({
    email: typeof search.email === "string" ? search.email : "",
  }),
  head: () => ({
    meta: [
      { title: "Verify Email · Harmony Physiotherapy" },
      {
        name: "description",
        content:
          "Verify your staff account email address to complete registration and unlock access to the Harmony Physiotherapy Clinic portal.",
      },
      { name: "robots", content: "noindex, nofollow" },
      { property: "og:title", content: "Verify Email · Harmony Physiotherapy" },
      {
        property: "og:description",
        content:
          "Verify your staff account email address to complete registration and unlock access to the Harmony Physiotherapy Clinic portal.",
      },
    ],
  }),
  component: VerifyEmailPage,
});

function VerifyEmailPage() {
  const nav = useNavigate();
  const { email } = Route.useSearch();
  const [loading, setLoading] = useState(false);
  const [cooldown, setCooldown] = useState(0);

  const canResend = useMemo(() => Boolean(email) && cooldown === 0 && !loading, [cooldown, email, loading]);

  useEffect(() => {
    const hash = window.location.hash;
    const params = new URLSearchParams(hash.startsWith("#") ? hash.slice(1) : hash);
    const type = params.get("type");
    const accessToken = params.get("access_token");
    const refreshToken = params.get("refresh_token");

    if (type === "signup" && accessToken && refreshToken) {
      void (async () => {
        const { error } = await supabase.auth.setSession({
          access_token: accessToken,
          refresh_token: refreshToken,
        });

        if (error) {
          toast.error(getAuthErrorMessage(error));
          return;
        }

        toast.success("Email verified. You can now access the staff portal.");
        window.history.replaceState({}, document.title, "/auth");
        nav({ to: "/bookings" });
      })();
    }
  }, [nav]);

  useEffect(() => {
    if (cooldown <= 0) return;
    const timer = window.setTimeout(() => setCooldown((value) => Math.max(0, value - 1)), 1000);
    return () => window.clearTimeout(timer);
  }, [cooldown]);

  const resend = async () => {
    if (!email) {
      toast.error("Add your email again from the sign up form.");
      return;
    }

    setLoading(true);
    try {
      const { error } = await supabase.auth.resend({
        type: "signup",
        email,
        options: { emailRedirectTo: `${window.location.origin}/auth/verify` },
      });
      if (error) throw error;
      setCooldown(60);
      toast.success("A new verification email has been sent.");
    } catch (error) {
      toast.error(getAuthErrorMessage(error));
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="flex min-h-screen items-center justify-center bg-midnight px-4 py-12">
      <section className="glass-strong w-full max-w-md space-y-5 rounded-3xl p-8 text-ice">
        <div className="flex items-center gap-3">
          <span className="flex h-11 w-11 items-center justify-center rounded-full bg-accent/15 text-accent">
            <MailCheck className="h-5 w-5" />
          </span>
          <div>
            <p className="text-xs uppercase tracking-[0.25em] text-accent">Verification</p>
            <h1 className="mt-1 text-3xl font-medium">Check your email</h1>
          </div>
        </div>

        <p className="text-sm text-ice/65">
          We sent a verification link {email ? <>to <span className="text-ice">{email}</span></> : "to your email address"}. Open it to activate your account.
        </p>

        <div className="rounded-xl border border-input bg-secondary/25 p-4 text-sm text-ice/70">
          If the message is not in your inbox, check spam or wait a few seconds before resending.
        </div>

        <Button type="button" className="w-full" onClick={resend} disabled={!canResend}>
          {loading ? "Sending…" : cooldown > 0 ? `Resend in ${cooldown}s` : "Resend Verification Email"}
        </Button>

        <div className="space-y-2 text-center text-xs text-ice/60">
          <Link to="/auth" className="block transition hover:text-accent">
            Back to sign in
          </Link>
          <Link to="/auth/forgot-password" className="block transition hover:text-accent">
            Need to reset your password instead?
          </Link>
        </div>
      </section>
    </main>
  );
}