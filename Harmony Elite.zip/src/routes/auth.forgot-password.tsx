import { Link, createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Mail } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { getAuthErrorMessage } from "@/lib/auth";
import { toast } from "sonner";

export const Route = createFileRoute("/auth/forgot-password")({
  head: () => ({
    meta: [
      { title: "Forgot Password · Harmony Physiotherapy" },
      {
        name: "description",
        content:
          "Request a secure password reset link for your Harmony Physiotherapy Clinic staff account to restore portal access.",
      },
      { name: "robots", content: "noindex, nofollow" },
      { property: "og:title", content: "Forgot Password · Harmony Physiotherapy" },
      {
        property: "og:description",
        content:
          "Request a secure password reset link for your Harmony Physiotherapy Clinic staff account to restore portal access.",
      },
    ],
  }),
  component: ForgotPasswordPage,
});

function ForgotPasswordPage() {
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setLoading(true);

    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/reset-password`,
      });

      if (error) throw error;

      setSent(true);
      toast.success("Password reset email sent. Check your inbox and spam folder.");
    } catch (error) {
      toast.error(getAuthErrorMessage(error));
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="flex min-h-screen items-center justify-center bg-midnight px-4 py-12">
      <form onSubmit={submit} className="glass-strong w-full max-w-md space-y-5 rounded-3xl p-8 text-ice">
        <div className="flex items-center gap-3">
          <span className="flex h-11 w-11 items-center justify-center rounded-full bg-accent/15 text-accent">
            <Mail className="h-5 w-5" />
          </span>
          <div>
            <p className="text-xs uppercase tracking-[0.25em] text-accent">Password reset</p>
            <h1 className="mt-1 text-3xl font-medium">Reset your password</h1>
          </div>
        </div>

        <p className="text-sm text-ice/65">
          Enter your staff email and we’ll send you a secure reset link.
        </p>

        <div>
          <Label>Email</Label>
          <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
        </div>

        {sent && (
          <div className="rounded-xl border border-accent/30 bg-accent/5 p-3 text-sm text-ice/75">
            If an account exists for {email}, a reset email is on the way.
          </div>
        )}

        <Button type="submit" className="w-full" disabled={loading}>
          {loading ? "Sending reset link…" : "Send reset link"}
        </Button>

        <Link to="/auth" className="block text-center text-xs text-ice/60 transition hover:text-accent">
          Back to sign in
        </Link>
      </form>
    </main>
  );
}