import { Link, createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { LockKeyhole } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PasswordStrength } from "@/components/auth/password-strength";
import { getAuthErrorMessage, isStrongPassword } from "@/lib/auth";
import { toast } from "sonner";

export const Route = createFileRoute("/reset-password")({
  head: () => ({
    meta: [
      { title: "Set New Password · Harmony Physiotherapy" },
      {
        name: "description",
        content:
          "Create a new secure password for your Harmony Physiotherapy Clinic staff account to regain portal access.",
      },
      { name: "robots", content: "noindex, nofollow" },
      { property: "og:title", content: "Set New Password · Harmony Physiotherapy" },
      {
        property: "og:description",
        content:
          "Create a new secure password for your Harmony Physiotherapy Clinic staff account to regain portal access.",
      },
    ],
  }),
  component: ResetPasswordPage,
});

function ResetPasswordPage() {
  const nav = useNavigate();
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [ready, setReady] = useState(false);
  const [invalidLink, setInvalidLink] = useState(false);

  const passwordsMatch = useMemo(() => password.length > 0 && password === confirmPassword, [confirmPassword, password]);

  useEffect(() => {
    const url = new URL(window.location.href);
    const hash = window.location.hash.startsWith("#")
      ? window.location.hash.slice(1)
      : window.location.hash;
    const hashParams = new URLSearchParams(hash);

    // Error in the link (expired/invalid)
    const hashError = hashParams.get("error_description") || hashParams.get("error");
    const queryError = url.searchParams.get("error_description") || url.searchParams.get("error");
    if (hashError || queryError) {
      setInvalidLink(true);
      toast.error(hashError || queryError || "Invalid reset link.");
      return;
    }

    // Listen for PASSWORD_RECOVERY — Supabase fires this after parsing the link
    const { data: sub } = supabase.auth.onAuthStateChange((event) => {
      if (event === "PASSWORD_RECOVERY" || event === "SIGNED_IN") {
        setReady(true);
      }
    });

    void (async () => {
      // PKCE flow: ?code=...
      const code = url.searchParams.get("code");
      if (code) {
        const { error } = await supabase.auth.exchangeCodeForSession(code);
        if (error) {
          setInvalidLink(true);
          toast.error(getAuthErrorMessage(error));
          return;
        }
        window.history.replaceState({}, document.title, "/reset-password");
        setReady(true);
        return;
      }

      // Implicit flow: #access_token=...&type=recovery
      const type = hashParams.get("type");
      const accessToken = hashParams.get("access_token");
      const refreshToken = hashParams.get("refresh_token");
      if (type === "recovery" && accessToken && refreshToken) {
        const { error } = await supabase.auth.setSession({
          access_token: accessToken,
          refresh_token: refreshToken,
        });
        if (error) {
          setInvalidLink(true);
          toast.error(getAuthErrorMessage(error));
          return;
        }
        window.history.replaceState({}, document.title, "/reset-password");
        setReady(true);
        return;
      }

      // Fallback: maybe Supabase already set a session via detectSessionInUrl
      const { data } = await supabase.auth.getSession();
      if (data.session) {
        setReady(true);
        return;
      }

      // Give onAuthStateChange a brief moment, otherwise mark invalid
      setTimeout(async () => {
        const { data: latest } = await supabase.auth.getSession();
        if (!latest.session) setInvalidLink(true);
      }, 1500);
    })();

    return () => {
      sub.subscription.unsubscribe();
    };
  }, []);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();

    if (!passwordsMatch) {
      toast.error("Passwords do not match.");
      return;
    }

    if (!isStrongPassword(password)) {
      toast.error("Use a stronger password before saving.");
      return;
    }

    setLoading(true);
    try {
      const { error } = await supabase.auth.updateUser({ password });
      if (error) throw error;

      toast.success("Password updated. You can now sign in.");
      window.history.replaceState({}, document.title, "/auth");
      nav({ to: "/auth" });
    } catch (error) {
      toast.error(getAuthErrorMessage(error));
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="flex min-h-screen items-center justify-center bg-midnight px-4 py-12">
      <form onSubmit={submit} className="glass-strong w-full max-w-md space-y-5 rounded-3xl p-8 text-ice">
        <div className="flex items-center gap-3">
          <span className="flex h-11 w-11 items-center justify-center rounded-full bg-accent/15 text-accent">
            <LockKeyhole className="h-5 w-5" />
          </span>
          <div>
            <p className="text-xs uppercase tracking-[0.25em] text-accent">New password</p>
            <h1 className="mt-1 text-3xl font-medium">Choose a new password</h1>
          </div>
        </div>

        {invalidLink ? (
          <div className="space-y-4 rounded-xl border border-destructive/30 bg-destructive/10 p-4 text-sm text-ice/75">
            <p>This reset link is invalid or has expired. Request a new one to continue.</p>
            <Link to="/auth/forgot-password" className="block text-accent transition hover:text-ice">
              Request a new reset link
            </Link>
          </div>
        ) : !ready ? (
          <div className="rounded-xl border border-input bg-secondary/25 p-4 text-sm text-ice/70">
            Validating your reset link…
          </div>
        ) : (
          <>
            <div>
              <Label>New password</Label>
              <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
            </div>
            <PasswordStrength password={password} />
            <div>
              <Label>Confirm new password</Label>
              <Input type="password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} required />
            </div>
            {confirmPassword && !passwordsMatch && (
              <p className="text-xs text-destructive">Passwords must match.</p>
            )}
            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? "Updating password…" : "Save new password"}
            </Button>
          </>
        )}

        <Link to="/auth" className="block text-center text-xs text-ice/60 transition hover:text-accent">
          Back to sign in
        </Link>
      </form>
    </main>
  );
}