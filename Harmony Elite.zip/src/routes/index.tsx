import { createFileRoute } from "@tanstack/react-router";
import { lazy, Suspense } from "react";
import { Header } from "@/components/Header";
import { Hero } from "@/components/Hero";
import { FloatingActions } from "@/components/FloatingActions";

// Below-the-fold: code-split to slim down the initial bundle.
const Doctors = lazy(() => import("@/components/Doctors").then((m) => ({ default: m.Doctors })));
const Services = lazy(() => import("@/components/Services").then((m) => ({ default: m.Services })));
const Reviews = lazy(() => import("@/components/Reviews").then((m) => ({ default: m.Reviews })));
const Booking = lazy(() => import("@/components/Booking").then((m) => ({ default: m.Booking })));
const Locations = lazy(() => import("@/components/Locations").then((m) => ({ default: m.Locations })));
const Footer = lazy(() => import("@/components/Footer").then((m) => ({ default: m.Footer })));

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Harmony Physiotherapy Clinic — Turn Your Pain Into Power" },
      {
        name: "description",
        content:
          "Elite adult physiotherapy and specialist lymphatic massage in New Cairo. Two branches, senior clinicians, premium care.",
      },
      {
        property: "og:title",
        content: "Harmony Physiotherapy Clinic — Expert Physiotherapy in New Cairo",
      },
      {
        property: "og:description",
        content: "Turn your pain into power. Premium physiotherapy in New Cairo.",
      },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "/" },
    ],
    links: [{ rel: "canonical", href: "/" }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "MedicalBusiness",
          "@id": "https://harmony-elite-care.lovable.app/#clinic",
          name: "Harmony Physiotherapy Clinic",
          description:
            "Elite adult physiotherapy and specialist lymphatic massage in New Cairo and Sheikh Zayed.",
          url: "https://harmony-elite-care.lovable.app/",
          medicalSpecialty: "Physiotherapy",
          priceRange: "$$",
          image:
            "https://storage.googleapis.com/gpt-engineer-file-uploads/4YMNZr8eE1a98MZUsZvULOrsUSc2/social-images/social-1781259102386-WhatsApp_Image_2026-06-12_at_12.40.32_PM.webp",
          sameAs: ["https://www.instagram.com/harmony_physio.eg/"],
          areaServed: ["New Cairo", "Sheikh Zayed", "Giza", "Cairo"],
          location: [
            {
              "@type": "Place",
              name: "Harmony Physiotherapy — Kazan Plaza, Fifth Settlement",
              address: {
                "@type": "PostalAddress",
                streetAddress: "Kazan Plaza, Fifth Settlement",
                addressLocality: "New Cairo",
                addressRegion: "Cairo",
                addressCountry: "EG",
              },
              telephone: "+201500097369",
              openingHoursSpecification: {
                "@type": "OpeningHoursSpecification",
                dayOfWeek: ["Saturday", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday"],
                opens: "10:00",
                closes: "21:00",
              },
            },
            {
              "@type": "Place",
              name: "Harmony Physiotherapy — Sheikh Zayed",
              address: {
                "@type": "PostalAddress",
                streetAddress: "Sheikh Zayed",
                addressLocality: "Sheikh Zayed",
                addressRegion: "Giza",
                addressCountry: "EG",
              },
              telephone: "+201500773731",
              openingHoursSpecification: {
                "@type": "OpeningHoursSpecification",
                dayOfWeek: ["Saturday", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday"],
                opens: "10:00",
                closes: "21:00",
              },
            },
          ],
          telephone: ["+201500097369", "+201500773731"],
        }),
      },
    ],

  }),
  component: Index,
});

function Index() {
  return (
    <main className="mobile-render-stable relative min-h-screen overflow-hidden bg-background text-foreground">
      <Header />
      <Hero />
      <Suspense fallback={<div className="h-[60vh]" />}>
        <Doctors />
        <Services />
        <Reviews />
        <Booking />
        <Locations />
        <Footer />
        <FloatingActions />
      </Suspense>
    </main>
  );
}
