import { motion, useReducedMotion } from "framer-motion";
import { format, startOfToday } from "date-fns";
import { ar as arLocale } from "date-fns/locale";
import { CalendarDays, Check, ChevronDown, Clock, Mail, MapPin, Phone, Stethoscope, User, Users } from "lucide-react";
import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { CLINIC } from "@/lib/clinic";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { createBooking, getTakenSlots, listDoctorsPublic } from "@/lib/bookings.functions";
import { supabase } from "@/integrations/supabase/client";
import { useI18n } from "@/lib/i18n";

// Canonical English values sent to backend (matches z.enum on the server).
const SERVICE_VALUES = [
  "Manual Therapy",
  "Lymphatic Massage",
  "Posture Correction Programs",
  "Recovery & Rehabilitation Programs",
  "Specialized Medical Assessment",
  "Spinal Column Treatment",
  "Sports Injury Rehabilitation",
];

const SLOTS = ["10:00", "11:00", "12:00", "14:00", "15:30", "17:00", "18:30", "20:00"];

function formatTime12(t: string) {
  const [hStr, mStr] = t.split(":");
  const h = Number(hStr);
  const period = h >= 12 ? "PM" : "AM";
  const h12 = ((h + 11) % 12) + 1;
  return `${h12}:${mStr} ${period}`;
}

export function Booking() {
  const { t, lang } = useI18n();
  const reduceMotion = useReducedMotion();
  const today = startOfToday();
  const locale = lang === "ar" ? arLocale : undefined;

  const [branch, setBranch] = useState<string>(CLINIC.branches[0].id);
  const [service, setService] = useState(SERVICE_VALUES[0]);
  const [date, setDate] = useState<Date>(today);
  const [dateOpen, setDateOpen] = useState(false);
  const [slot, setSlot] = useState<string>(SLOTS[0]);
  const [fullName, setFullName] = useState("");
  const [gender, setGender] = useState<"male" | "female">("male");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [doctorId, setDoctorId] = useState<string>("");
  const [done, setDone] = useState(false);

  const selectedBranch = CLINIC.branches.find((b) => b.id === branch)!;
  const createFn = useServerFn(createBooking);
  const takenFn = useServerFn(getTakenSlots);
  const doctorsFn = useServerFn(listDoctorsPublic);
  const queryClient = useQueryClient();
  const dateKey = format(date, "yyyy-MM-dd");

  const doctorsQuery = useQuery({
    queryKey: ["doctors-public"],
    queryFn: () => doctorsFn(),
    staleTime: 60_000,
  });

  // Localized service labels (display only — submit English value)
  const serviceLabel = (val: string) => {
    const idx = SERVICE_VALUES.indexOf(val);
    return idx >= 0 ? t.services.items[idx]?.title ?? val : val;
  };

  const takenQuery = useQuery({
    queryKey: ["taken-slots", selectedBranch.id, dateKey],
    queryFn: () => takenFn({ data: { branch_id: selectedBranch.id, booking_date: dateKey } }),
    staleTime: 15_000,
  });
  const taken = new Set(takenQuery.data?.times ?? []);

  useEffect(() => {
    const channel = supabase
      .channel(`bookings-${selectedBranch.id}-${dateKey}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "bookings", filter: `branch_id=eq.${selectedBranch.id}` },
        () => queryClient.invalidateQueries({ queryKey: ["taken-slots", selectedBranch.id, dateKey] }),
      )
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [selectedBranch.id, dateKey, queryClient]);

  useEffect(() => {
    if (taken.has(slot)) {
      const free = SLOTS.find((s) => !taken.has(s));
      if (free) setSlot(free);
    }
  }, [takenQuery.data]); // eslint-disable-line react-hooks/exhaustive-deps

  const submit = useMutation({
    mutationFn: createFn,
    onSuccess: () => {
      setDone(true);
      toast.success(t.booking.toast.ok);
      queryClient.invalidateQueries({ queryKey: ["taken-slots", selectedBranch.id, dateKey] });
    },
    onError: (e: Error) => toast.error(e.message || t.booking.toast.err),
  });

  function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (fullName.trim().length < 2) return toast.error(t.booking.toast.needName);
    if (phone.trim().length < 6) return toast.error(t.booking.toast.needPhone);
    submit.mutate({
      data: {
        branch_id: selectedBranch.id,
        branch_label: selectedBranch.label,
        service,
        booking_date: format(date, "yyyy-MM-dd"),
        booking_time: slot,
        full_name: fullName.trim(),
        gender,
        phone: phone.trim(),
        email: email.trim() || undefined,
        doctor_id: doctorId || null,
      },
    });
  }

  const dateLong = format(date, "EEEE, MMM d", { locale });
  const dateShort = format(date, "EEE d MMM", { locale });

  return (
    <section id="booking" className="relative scroll-mt-24 py-20 sm:py-36">
      <div className="absolute inset-0 -z-10 bg-gradient-to-b from-midnight via-midnight/95 to-midnight" />
      <div className="mx-auto max-w-3xl px-4 sm:px-5 lg:px-8">
        <motion.div
          initial={reduceMotion ? false : { opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: reduceMotion ? 0 : 0.8 }}
          className="mb-8 sm:mb-12"
        >
          <p className="mb-3 text-xs uppercase tracking-[0.25em] text-accent">{t.booking.eyebrow}</p>
          <h2 className="text-balance text-4xl font-medium leading-tight text-ice sm:text-5xl">
            {t.booking.title}
          </h2>
          <p className="mt-4 text-sm text-ice/70 sm:mt-5 sm:text-base">{t.booking.sub}</p>
        </motion.div>

        {done ? (
          <motion.div
            initial={reduceMotion ? false : { opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: reduceMotion ? 0 : 0.2 }}
            className="glass-strong rounded-3xl p-8 text-center"
          >
            <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-accent/15 text-accent">
              <Check className="h-7 w-7" />
            </div>
            <h3 className="text-xl font-medium text-ice">{t.booking.successTitle}</h3>
            <p className="mt-2 text-sm text-ice/70">
              {t.booking.successBody(
                fullName.split(" ")[0],
                phone,
                serviceLabel(service),
                dateLong,
                formatTime12(slot),
              )}
            </p>
            <button
              onClick={() => setDone(false)}
              className="mt-6 text-xs uppercase tracking-[0.22em] text-accent hover:underline"
            >
              {t.booking.successCta}
            </button>
          </motion.div>
        ) : (
          <motion.form
            onSubmit={onSubmit}
            initial={reduceMotion ? false : { opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={reduceMotion ? { duration: 0 } : { duration: 0.9, ease: [0.2, 0.8, 0.2, 1] }}
            className="glass-strong space-y-3 rounded-3xl p-4 sm:space-y-4 sm:p-7"
          >
            <SelectField icon={MapPin} label={t.booking.branch} value={branch} onChange={setBranch}>
              {CLINIC.branches.map((b) => (
                <option key={b.id} value={b.id}>{b.label}</option>
              ))}
            </SelectField>

            <SelectField icon={Stethoscope} label={t.booking.service} value={service} onChange={setService}>
              {SERVICE_VALUES.map((s) => (
                <option key={s} value={s}>{serviceLabel(s)}</option>
              ))}
            </SelectField>

            <label className="block">
              <span className="mb-2 inline-flex items-center gap-2 text-[11px] uppercase tracking-[0.22em] text-accent">
                <CalendarDays className="h-3.5 w-3.5" /> {t.booking.date}
              </span>
              <Popover open={dateOpen} onOpenChange={setDateOpen}>
                <PopoverTrigger asChild>
                  <button
                    type="button"
                    className={cn(
                      "flex w-full items-center justify-between gap-2 rounded-2xl border border-white/10 bg-white/[0.04] px-4 py-4 text-start text-base text-ice outline-none transition focus:border-accent/60 focus:bg-white/[0.07] sm:text-sm",
                    )}
                  >
                    <span>{dateLong}</span>
                    <ChevronDown className="h-4 w-4 text-ice/60" />
                  </button>
                </PopoverTrigger>
                <PopoverContent align="start" className="w-auto p-0 pointer-events-auto">
                  <Calendar
                    mode="single"
                    selected={date}
                    onSelect={(d) => {
                      if (d) {
                        setDate(d);
                        setDateOpen(false);
                      }
                    }}
                    disabled={(d) => d < today}
                    autoFocus
                    locale={locale}
                    className="pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>
            </label>

            <SelectField icon={Clock} label={t.booking.time} value={slot} onChange={setSlot}>
              {SLOTS.map((s) => (
                <option key={s} value={s} disabled={taken.has(s)}>
                  {formatTime12(s)}{taken.has(s) ? ` — ${t.booking.booked}` : ""}
                </option>
              ))}
            </SelectField>

            <InputField
              icon={User}
              label={t.booking.fullName}
              value={fullName}
              onChange={setFullName}
              placeholder={t.booking.fullNamePh}
              autoComplete="name"
              required
            />

            <SelectField
              icon={Users}
              label={t.booking.gender}
              value={gender}
              onChange={(v) => setGender(v as "male" | "female")}
            >
              <option value="male">{t.booking.male}</option>
              <option value="female">{t.booking.female}</option>
            </SelectField>

            {doctorsQuery.data && doctorsQuery.data.length > 0 && (
              <SelectField icon={Stethoscope} label="Preferred doctor" value={doctorId} onChange={setDoctorId}>
                <option value="">No preference</option>
                {doctorsQuery.data.map((d: any) => (
                  <option key={d.id} value={d.id}>
                    {d.title ? `${d.title} ` : ""}{d.name}
                  </option>
                ))}
              </SelectField>
            )}

            <InputField
              icon={Phone}
              label={t.booking.phone}
              value={phone}
              onChange={setPhone}
              placeholder={t.booking.phonePh}
              type="tel"
              autoComplete="tel"
              required
              dir="ltr"
            />

            <InputField
              icon={Mail}
              label="Email (optional)"
              value={email}
              onChange={setEmail}
              placeholder="you@example.com"
              type="email"
              autoComplete="email"
              dir="ltr"
            />

            <button
              type="submit"
              disabled={submit.isPending}
              className="group mt-2 flex w-full items-center justify-center gap-2 rounded-2xl bg-ice px-5 py-4 text-sm font-medium text-midnight transition disabled:opacity-60 sm:px-6"
            >
              {submit.isPending ? t.booking.sending : t.booking.submit(dateShort, formatTime12(slot))}
            </button>
            <p className="text-[11px] text-muted-foreground">{t.booking.note}</p>
          </motion.form>
        )}
      </div>
    </section>
  );
}

function SelectField({
  icon: Icon,
  label,
  value,
  onChange,
  children,
}: {
  icon: any;
  label: string;
  value: string;
  onChange: (v: string) => void;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-2 inline-flex items-center gap-2 text-[11px] uppercase tracking-[0.22em] text-accent">
        <Icon className="h-3.5 w-3.5" /> {label}
      </span>
      <div className="relative">
        <select
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="w-full appearance-none rounded-2xl border border-white/10 bg-white/[0.04] px-4 py-4 pe-11 text-base text-ice outline-none transition focus:border-accent/60 focus:bg-white/[0.07] sm:text-sm [&>option]:bg-midnight [&>option]:text-ice"
        >
          {children}
        </select>
        <ChevronDown className="pointer-events-none absolute end-4 top-1/2 h-4 w-4 -translate-y-1/2 text-ice/60" />
      </div>
    </label>
  );
}

function InputField({
  icon: Icon,
  label,
  value,
  onChange,
  ...rest
}: {
  icon: any;
  label: string;
  value: string;
  onChange: (v: string) => void;
} & Omit<React.InputHTMLAttributes<HTMLInputElement>, "value" | "onChange">) {
  return (
    <label className="block">
      <span className="mb-2 inline-flex items-center gap-2 text-[11px] uppercase tracking-[0.22em] text-accent">
        <Icon className="h-3.5 w-3.5" /> {label}
      </span>
      <input
        {...rest}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-2xl border border-white/10 bg-white/[0.04] px-4 py-4 text-base text-ice outline-none transition placeholder:text-ice/30 focus:border-accent/60 focus:bg-white/[0.07] sm:text-sm"
      />
    </label>
  );
}
