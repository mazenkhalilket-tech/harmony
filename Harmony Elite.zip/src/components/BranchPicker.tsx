import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { MessageCircle, Phone, X } from "lucide-react";
import { CLINIC } from "@/lib/clinic";
import { useI18n } from "@/lib/i18n";

type Intent = "whatsapp" | "book" | "call";

export function BranchPicker({
  open,
  intent,
  onClose,
}: {
  open: boolean;
  intent: Intent;
  onClose: () => void;
}) {
  const { t } = useI18n();
  const reduceMotion = useReducedMotion();
  const title = intent === "call" ? t.branchPicker.callTitle : t.branchPicker.bookTitle;
  const subtitle = intent === "call" ? t.branchPicker.callSub : t.branchPicker.bookSub;

  const hrefFor = (b: typeof CLINIC.branches[number]) =>
    intent === "call"
      ? `tel:${b.phoneIntl}`
      : `${b.whatsapp}?text=${encodeURIComponent(t.branchPicker.waMessage(b.label))}`;

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-[100] flex items-end justify-center bg-midnight/70 p-4 backdrop-blur-md sm:items-center"
          initial={reduceMotion ? false : { opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: reduceMotion ? 0 : 0.2 }}
          onClick={onClose}
        >
          <motion.div
            className="glass-strong w-full max-w-md overflow-hidden rounded-2xl p-6 shadow-elevated"
            initial={reduceMotion ? false : { y: 40, opacity: 0, scale: 0.96 }}
            animate={{ y: 0, opacity: 1, scale: 1 }}
            exit={{ y: 40, opacity: 0, scale: 0.96 }}
            transition={reduceMotion ? { duration: 0 } : { type: "spring", damping: 22, stiffness: 240 }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mb-5 flex items-start justify-between gap-4">
              <div>
                <h3 className="text-xl font-semibold text-ice">{title}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{subtitle}</p>
              </div>
              <button
                aria-label={t.branchPicker.close}
                onClick={onClose}
                className="rounded-full p-2 text-muted-foreground transition hover:bg-white/5 hover:text-ice"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="space-y-3">
              {CLINIC.branches.map((b) => (
                <a
                  key={b.id}
                  href={hrefFor(b)}
                  target={intent === "call" ? undefined : "_blank"}
                  rel="noreferrer"
                  className="group flex items-center justify-between gap-4 rounded-xl border border-white/10 bg-white/[0.03] p-4 transition hover:border-accent/60 hover:bg-white/[0.06]"
                >
                  <div className="min-w-0">
                    <p className="truncate font-medium text-ice" dir="ltr">{b.label}</p>
                    <p className="truncate text-xs text-muted-foreground" dir="ltr">{b.phone}</p>
                  </div>
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-accent/15 text-accent transition group-hover:bg-accent group-hover:text-accent-foreground">
                    {intent === "call" ? <Phone className="h-4 w-4" /> : <MessageCircle className="h-4 w-4" />}
                  </span>
                </a>
              ))}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
