import { motion, useReducedMotion } from "framer-motion";
import {
  Activity,
  Droplets,
  HeartPulse,
  Hand,
  Stethoscope,
  Bone,
  Sparkles,
  Spline,
} from "lucide-react";
import { useI18n } from "@/lib/i18n";

const ICONS = [Hand, Droplets, Spline, HeartPulse, Stethoscope, Bone, Activity];
const ACCENT_INDEX = 1; // Lymphatic Massage

export function Services() {
  const { t } = useI18n();
  const reduceMotion = useReducedMotion();
  const services = t.services.items.map((s, i) => ({
    ...s,
    icon: ICONS[i] ?? Activity,
    accent: i === ACCENT_INDEX,
  }));

  return (
    <section id="services" className="relative py-28 sm:py-36">
      <div className="absolute inset-0 -z-10 bg-gradient-to-b from-transparent via-midnight/60 to-transparent" />
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <motion.div
          initial={reduceMotion ? false : { opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: reduceMotion ? 0 : 0.7 }}
          className="mb-16 max-w-2xl"
        >
          <p className="mb-4 text-xs uppercase tracking-[0.25em] text-accent">{t.services.eyebrow}</p>
          <h2 className="text-balance text-4xl font-medium leading-tight text-ice sm:text-5xl">
            {t.services.title}
          </h2>
          <p className="mt-5 text-muted-foreground">{t.services.sub}</p>
        </motion.div>

        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {services.map((s, i) => (
            <motion.div
              key={s.title}
              initial={reduceMotion ? false : { opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.15 }}
              transition={{ duration: reduceMotion ? 0 : 0.5, delay: reduceMotion ? 0 : Math.min(i * 0.05, 0.25) }}
              className={`group relative overflow-hidden rounded-2xl p-7 transition duration-300 ${
                s.accent
                  ? "glass-strong ring-1 ring-accent/30"
                  : "glass hover:ring-1 hover:ring-white/20"
              }`}
            >
              {s.accent && (
                <div className="absolute -end-12 -top-12 h-40 w-40 rounded-full bg-accent/20 blur-3xl" />
              )}
              <div className="relative">
                <div className="mb-5 inline-flex h-12 w-12 items-center justify-center rounded-xl bg-white/5 ring-1 ring-white/10 transition group-hover:bg-accent/15 group-hover:ring-accent/40">
                  <s.icon className="h-5 w-5 text-accent" />
                </div>
                <h3 className="font-display text-xl text-ice">{s.title}</h3>
                <ul className="mt-3 space-y-1.5 text-sm leading-relaxed text-muted-foreground">
                  {s.items.map((item) => (
                    <li key={item} className="flex gap-2">
                      <span className="mt-2 h-1 w-1 shrink-0 rounded-full bg-accent/70" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
                {s.accent && (
                  <span className="mt-5 inline-flex items-center gap-1.5 rounded-full bg-accent/15 px-3 py-1 text-[10px] uppercase tracking-wider text-accent">
                    <Sparkles className="h-3 w-3" /> {t.services.signature}
                  </span>
                )}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
