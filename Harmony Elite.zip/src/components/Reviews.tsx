import { motion, useReducedMotion } from "framer-motion";
import { Star } from "lucide-react";
import { useRef, useState } from "react";
import r1 from "@/assets/review-1.asset.json";
import r2 from "@/assets/review-2.asset.json";
import v2 from "@/assets/clinic-video-2.asset.json";
import { useI18n } from "@/lib/i18n";

export function Reviews() {
  const { t } = useI18n();
  const reduceMotion = useReducedMotion();
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [started, setStarted] = useState(false);

  const handlePlay = () => {
    const v = videoRef.current;
    if (!v) return;
    v.muted = false;
    v.volume = 1;
    setStarted(true);
    v.play().catch(() => {});
  };

  return (
    <section className="relative py-20 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <motion.div
          initial={reduceMotion ? false : { opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: reduceMotion ? 0 : 0.8 }}
          className="mb-10 flex items-end justify-between gap-6 sm:mb-14"
        >
          <div className="max-w-2xl">
            <p className="mb-3 text-xs uppercase tracking-[0.25em] text-accent">{t.reviews.eyebrow}</p>
            <h2 className="text-balance text-4xl font-medium leading-tight text-ice sm:text-5xl">
              {t.reviews.title}
            </h2>
          </div>
          <div className="hidden items-center gap-1 sm:flex">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star key={i} className="h-4 w-4 fill-accent text-accent" />
            ))}
          </div>
        </motion.div>

        <div className="grid gap-6 md:grid-cols-2">
          {[r1, r2].map((r, i) => (
            <motion.div
              key={i}
              initial={reduceMotion ? false : { opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: reduceMotion ? 0 : 0.7, delay: reduceMotion ? 0 : i * 0.1 }}
              className="glass overflow-hidden rounded-3xl p-2"
            >
              <img src={r.url} alt={`Patient review ${i + 1}`} loading="lazy" decoding="async" className="w-full rounded-2xl object-cover" />
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={reduceMotion ? false : { opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={reduceMotion ? { duration: 0 } : { duration: 0.8, ease: [0.2, 0.8, 0.2, 1] }}
          className="relative mt-8 overflow-hidden rounded-3xl bg-midnight ring-1 ring-white/10 shadow-elevated sm:mt-12"
        >
          <video
            ref={videoRef}
            src={v2.url}
            playsInline
            preload="metadata"
            controls
            onPlay={() => {
              if (videoRef.current) {
                videoRef.current.muted = false;
              }
              setStarted(true);
            }}
            className="block h-auto max-h-[75vh] w-full object-contain"
          />
          {!started && (
            <button
              type="button"
              onClick={handlePlay}
              className="absolute inset-0 flex items-center justify-center bg-midnight/40 backdrop-blur-sm transition hover:bg-midnight/30"
              aria-label={t.reviews.playAria}
            >
              <span className="flex h-20 w-20 items-center justify-center rounded-full bg-ice text-midnight shadow-elevated">
                <svg viewBox="0 0 24 24" className="h-8 w-8 translate-x-0.5 fill-current"><path d="M8 5v14l11-7z"/></svg>
              </span>
            </button>
          )}
        </motion.div>
      </div>
    </section>
  );
}
