import { Instagram, MapPin, Phone } from "lucide-react";
import logo from "@/assets/logo.asset.json";
import { CLINIC } from "@/lib/clinic";
import { useI18n } from "@/lib/i18n";

export function Footer() {
  const { t } = useI18n();
  return (
    <footer className="relative border-t border-white/10 py-16">
      <div className="mx-auto grid max-w-7xl gap-12 px-5 lg:grid-cols-4 lg:px-8">
        <div className="lg:col-span-2">
          <div className="flex items-center gap-3">
            <img src={logo.url} alt="Harmony Physiotherapy logo" className="h-10 w-10 rounded-lg object-cover ring-1 ring-white/15" />
            <div>
              <p className="font-display text-lg text-ice">Harmony Physiotherapy</p>
              <p className="text-xs uppercase tracking-[0.2em] text-accent">{t.footer.tagline}</p>
            </div>
          </div>
          <p className="mt-5 max-w-md text-sm text-muted-foreground">{t.footer.about}</p>
          <div className="mt-6 flex gap-3">
            <a
              href={CLINIC.instagram}
              target="_blank" rel="noreferrer"
              aria-label="Instagram"
              className="flex h-10 w-10 items-center justify-center rounded-full border border-white/10 transition hover:border-accent hover:text-accent"
            >
              <Instagram className="h-4 w-4" />
            </a>
          </div>
        </div>

        {CLINIC.branches.map((b) => (
          <div key={b.id}>
            <p className="text-xs uppercase tracking-[0.2em] text-accent" dir="ltr">{b.label.split("—")[0].trim()}</p>
            <p className="mt-3 inline-flex items-start gap-2 text-sm text-ice">
              <MapPin className="mt-0.5 h-3.5 w-3.5 text-muted-foreground" />
              <span dir="ltr">{b.address}</span>
            </p>
            <a href={`tel:${b.phoneIntl}`} className="mt-2 flex items-center gap-2 text-sm text-muted-foreground transition hover:text-ice">
              <Phone className="h-3.5 w-3.5" /> <span dir="ltr">{b.phone}</span>
            </a>
          </div>
        ))}
      </div>
      <div className="mx-auto mt-12 max-w-7xl border-t border-white/10 px-5 pt-6 text-xs text-muted-foreground lg:px-8">
        © {new Date().getFullYear()} Harmony Physiotherapy Clinic. {t.footer.rights}
      </div>
    </footer>
  );
}
