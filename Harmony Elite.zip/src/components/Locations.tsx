import { motion, useReducedMotion } from "framer-motion";
import { MapPin, MessageCircle, Navigation, Phone } from "lucide-react";
import { CLINIC } from "@/lib/clinic";
import { useI18n } from "@/lib/i18n";

export function Locations() {
  const { t } = useI18n();
  const reduceMotion = useReducedMotion();
  return (
    <section id="locations" className="relative py-28 sm:py-36">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <motion.div
          initial={reduceMotion ? false : { opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: reduceMotion ? 0 : 0.8 }}
          className="mb-14 max-w-2xl"
        >
          <p className="mb-4 text-xs uppercase tracking-[0.25em] text-accent">{t.locations.eyebrow}</p>
          <h2 className="text-balance text-4xl font-medium leading-tight text-ice sm:text-5xl">
            {t.locations.title}
          </h2>
        </motion.div>

        <div className="grid gap-6 lg:grid-cols-2">
          {CLINIC.branches.map((b, i) => (
            <motion.div
              key={b.id}
              initial={reduceMotion ? false : { opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: reduceMotion ? 0 : 0.7, delay: reduceMotion ? 0 : i * 0.1 }}
              className="glass overflow-hidden rounded-3xl"
            >
              <iframe
                title={b.label}
                src={b.mapsEmbed}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                className="h-64 w-full border-0 [filter:invert(0.92)_hue-rotate(180deg)_saturate(0.85)]"
              />
              <div className="space-y-5 p-7">
                <div>
                  <p className="text-xs uppercase tracking-[0.2em] text-accent">{t.locations.brand}</p>
                  <h3 className="mt-1 font-display text-2xl text-ice" dir="ltr">{b.label}</h3>
                  <p className="mt-2 inline-flex items-center gap-2 text-sm text-muted-foreground">
                    <MapPin className="h-3.5 w-3.5" /> <span dir="ltr">{b.address}</span>
                  </p>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  <a
                    href={`tel:${b.phoneIntl}`}
                    className="flex flex-col items-center gap-1.5 rounded-xl border border-white/10 bg-white/[0.03] p-3 text-xs text-ice transition hover:border-accent/40 hover:bg-white/[0.06]"
                  >
                    <Phone className="h-4 w-4 text-accent" /> {t.locations.call}
                  </a>
                  <a
                    href={b.whatsapp}
                    target="_blank"
                    rel="noreferrer"
                    className="flex flex-col items-center gap-1.5 rounded-xl border border-white/10 bg-white/[0.03] p-3 text-xs text-ice transition hover:border-accent/40 hover:bg-white/[0.06]"
                  >
                    <MessageCircle className="h-4 w-4 text-accent" /> {t.locations.whatsapp}
                  </a>
                  <a
                    href={b.maps}
                    target="_blank"
                    rel="noreferrer"
                    className="flex flex-col items-center gap-1.5 rounded-xl border border-white/10 bg-white/[0.03] p-3 text-xs text-ice transition hover:border-accent/40 hover:bg-white/[0.06]"
                  >
                    <Navigation className="h-4 w-4 text-accent" /> {t.locations.directions}
                  </a>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
