import { AnimatePresence, motion, useReducedMotion, useScroll, useTransform } from "framer-motion";
import { Menu, Phone, X } from "lucide-react";
import { useState } from "react";
import logo from "@/assets/logo.asset.json";
import { BranchPicker } from "./BranchPicker";
import { LanguageToggle, useI18n } from "@/lib/i18n";

export function Header() {
  const reduceMotion = useReducedMotion();
  const { scrollY } = useScroll();
  const opacity = useTransform(scrollY, [0, 80], reduceMotion ? [1, 1] : [0, 1]);
  const [callOpen, setCallOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const { t } = useI18n();

  const links = [
    { href: "#services", label: t.nav.services },
    { href: "#doctors", label: t.nav.doctors },
    { href: "#locations", label: t.nav.locations },
    { href: "#booking", label: t.nav.booking },
  ];

  return (
    <>
      <motion.header
        initial={reduceMotion ? false : { y: -30, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={reduceMotion ? { duration: 0 } : { duration: 0.8, ease: [0.2, 0.8, 0.2, 1] }}
        className="fixed inset-x-0 top-0 z-40"
      >
        <motion.div
          style={{ opacity }}
          className="glass absolute inset-0 border-b border-white/10"
        />
        <div className="relative mx-auto flex max-w-7xl items-center justify-between gap-4 px-5 py-3 lg:px-8">
          <a href="#top" className="flex items-center gap-3">
            <img src={logo.url} alt="Harmony Physiotherapy logo" className="h-9 w-9 rounded-lg object-cover ring-1 ring-white/15" />
            <div className="hidden flex-col leading-tight sm:flex">
              <span className="text-sm font-semibold tracking-wide text-ice">HARMONY</span>
              <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">Physiotherapy</span>
            </div>
          </a>

          <nav className="hidden items-center gap-7 lg:flex">
            {links.map((l) => (
              <a
                key={l.href}
                href={l.href}
                className="text-sm text-muted-foreground transition hover:text-ice"
              >
                {l.label}
              </a>
            ))}
            <a href="/auth" className="text-sm text-accent transition hover:text-ice">
              {t.nav.staff}
            </a>
          </nav>

          <div className="flex items-center gap-2">
            <LanguageToggle className="hidden sm:inline-flex" />
            <button
              onClick={() => setCallOpen(true)}
              aria-label={t.nav.call}
              className="flex h-10 w-10 items-center justify-center rounded-full border border-white/15 text-ice transition hover:bg-white/5"
            >
              <Phone className="h-4 w-4" />
            </button>
            <a
              href="#booking"
              className="relative overflow-hidden rounded-full bg-ice px-4 py-2 text-sm font-medium text-midnight transition sm:px-5 sm:py-2.5"
            >
              {t.nav.book}
            </a>
            <button
              onClick={() => setMenuOpen(true)}
              aria-label={t.nav.menu}
              className="flex h-10 w-10 items-center justify-center rounded-full border border-white/15 text-ice transition hover:bg-white/5 lg:hidden"
            >
              <Menu className="h-4 w-4" />
            </button>
          </div>
        </div>
      </motion.header>

      <AnimatePresence>
        {menuOpen && (
          <motion.div
            initial={reduceMotion ? false : { opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: reduceMotion ? 0 : 0.25 }}
            className="fixed inset-0 z-50 lg:hidden"
          >
            <div
              className="absolute inset-0 bg-midnight/88"
              onClick={() => setMenuOpen(false)}
            />
            <motion.div
              initial={reduceMotion ? false : { x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={reduceMotion ? { duration: 0 } : { duration: 0.35, ease: [0.2, 0.8, 0.2, 1] }}
              className="glass-strong absolute end-0 top-0 flex h-full w-[82%] max-w-sm flex-col gap-2 border-s border-white/10 px-6 pb-10 pt-6"
            >
              <div className="mb-6 flex items-center justify-between">
                <span className="text-xs uppercase tracking-[0.25em] text-accent">{t.nav.menu}</span>
                <button
                  onClick={() => setMenuOpen(false)}
                  aria-label={t.nav.close}
                  className="flex h-9 w-9 items-center justify-center rounded-full border border-white/15 text-ice transition hover:bg-white/5"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
              {links.map((l) => (
                <a
                  key={l.href}
                  href={l.href}
                  onClick={() => setMenuOpen(false)}
                  className="border-b border-white/5 py-4 text-lg text-ice transition hover:text-accent"
                >
                  {l.label}
                </a>
              ))}
              <a
                href="/auth"
                onClick={() => setMenuOpen(false)}
                className="py-4 text-lg text-accent transition hover:text-ice"
              >
                {t.nav.staff}
              </a>
              <div className="mt-4">
                <LanguageToggle />
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <BranchPicker open={callOpen} intent="call" onClose={() => setCallOpen(false)} />
    </>
  );
}
