import { motion, useReducedMotion } from "framer-motion";
import { ArrowRight, Sparkles } from "lucide-react";
import v1 from "@/assets/clinic-video-1.asset.json";
import { useI18n } from "@/lib/i18n";

export function Hero() {
  const { t, dir } = useI18n();
  const reduceMotion = useReducedMotion();
  return (
    <section id="top" className="relative isolate overflow-hidden pt-32 pb-24 sm:pt-40 sm:pb-32">
      <div className="bg-aurora absolute inset-0 -z-10" />
      <div className="animate-aurora-shift absolute -top-40 left-1/2 -z-10 h-[500px] w-[800px] -translate-x-1/2 rounded-full bg-glow/20 blur-[80px] sm:h-[800px] sm:w-[1200px] sm:blur-[160px]" />
      <div className="absolute inset-0 -z-10 opacity-[0.04] [background-image:radial-gradient(circle_at_1px_1px,white_1px,transparent_0)] [background-size:32px_32px]" />

      <div className="mx-auto grid max-w-7xl gap-12 px-5 lg:grid-cols-[1.1fr_0.9fr] lg:items-center lg:px-8">
        <div>
          <motion.div
            initial={reduceMotion ? false : { opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: reduceMotion ? 0 : 0.7 }}
            className="glass mb-6 inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-xs uppercase tracking-[0.18em] text-ice/80"
          >
            <Sparkles className="h-3 w-3 text-accent" />
            {t.hero.badge}
          </motion.div>

          <motion.h1
            initial={reduceMotion ? false : { opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: reduceMotion ? 0 : 0.9, delay: reduceMotion ? 0 : 0.1, ease: [0.2, 0.8, 0.2, 1] }}
            className="text-balance text-[clamp(2.6rem,7vw,5.5rem)] font-medium leading-[0.95]"
          >
            <span className="text-gradient">{t.hero.titleA}</span>
            <br />
            <span className="text-ice">{t.hero.titleB}</span>
          </motion.h1>

          <motion.p
            initial={reduceMotion ? false : { opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: reduceMotion ? 0 : 0.8, delay: reduceMotion ? 0 : 0.3 }}
            className="mt-6 max-w-xl text-pretty text-base text-muted-foreground sm:text-lg"
          >
            {t.hero.sub}
          </motion.p>

          <motion.div
            initial={reduceMotion ? false : { opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: reduceMotion ? 0 : 0.8, delay: reduceMotion ? 0 : 0.45 }}
            className="mt-9 flex flex-wrap items-center gap-3"
          >
            <a
              href="#booking"
              className="lift group inline-flex items-center gap-2 rounded-full bg-ice px-6 py-3.5 text-sm font-medium text-midnight transition hover:[--lift:translateY(-3px)] hover:shadow-glow"
            >
              {t.hero.bookCta}
              <ArrowRight className={`h-4 w-4 transition group-hover:translate-x-1 ${dir === "rtl" ? "rotate-180" : ""}`} />
            </a>
            <a
              href="#services"
              className="glass inline-flex items-center gap-2 rounded-full px-6 py-3.5 text-sm font-medium text-ice transition hover:bg-white/10"
            >
              {t.hero.exploreCta}
            </a>
          </motion.div>

          <motion.div
            initial={reduceMotion ? false : { opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: reduceMotion ? 0 : 1, delay: reduceMotion ? 0 : 0.7 }}
            className="mt-14 grid max-w-md grid-cols-3 gap-6"
          >
            {t.hero.stats.map((s) => (
              <div key={s.v}>
                <div className="font-display text-3xl text-ice">{s.k}</div>
                <div className="mt-1 text-xs uppercase tracking-wider text-muted-foreground">{s.v}</div>
              </div>
            ))}
          </motion.div>
        </div>

        <motion.div
          initial={reduceMotion ? false : { opacity: 0, scale: 0.95, y: 30 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: reduceMotion ? 0 : 1, delay: reduceMotion ? 0 : 0.3, ease: [0.2, 0.8, 0.2, 1] }}
          className="relative"
        >
          <div className="animate-float relative aspect-[4/5] overflow-hidden rounded-3xl ring-1 ring-white/10 shadow-elevated">
            <video
              src={v1.url}
              autoPlay
              loop
              muted
              playsInline
              preload="metadata"
              className="h-full w-full object-cover"
            />
            <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-midnight/40 via-transparent to-transparent" />
          </div>
          <div className="absolute -inset-10 -z-10 bg-glow/20 blur-[60px] sm:blur-[120px]" />
        </motion.div>
      </div>
    </section>
  );
}
