import { motion, useReducedMotion } from "framer-motion";
import drAmr from "@/assets/dr-amr.asset.json";
import drAnan from "@/assets/dr-anan.asset.json";
import drPassant from "@/assets/dr-passant.asset.json";
import { useI18n } from "@/lib/i18n";

const IMGS = [drAmr.url, drAnan.url, drPassant.url];
const ALTS = ["Dr. Amr Eltourky", "Dr. Anan Atef", "Dr. Passant Elseoudie"];

export function Doctors() {
  const { t } = useI18n();
  const reduceMotion = useReducedMotion();
  const doctors = t.doctors.list.map((d, i) => ({ ...d, img: IMGS[i], alt: ALTS[i] }));

  return (
    <section id="doctors" className="relative py-28 sm:py-36">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <motion.div
          initial={reduceMotion ? false : { opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: reduceMotion ? 0 : 0.8 }}
          className="mb-16 flex flex-col items-start justify-between gap-6 sm:flex-row sm:items-end"
        >
          <div className="max-w-2xl">
            <p className="mb-4 text-xs uppercase tracking-[0.25em] text-accent">{t.doctors.eyebrow}</p>
            <h2 className="text-balance text-4xl font-medium leading-tight text-ice sm:text-5xl">
              {t.doctors.title}
            </h2>
            <p className="mt-5 text-muted-foreground">{t.doctors.sub}</p>
          </div>
        </motion.div>

        <div className="grid gap-6 md:grid-cols-3">
          {doctors.map((d, i) => (
            <motion.article
              key={d.name}
              initial={reduceMotion ? false : { opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: reduceMotion ? 0 : 0.7, delay: reduceMotion ? 0 : i * 0.1, ease: [0.2, 0.8, 0.2, 1] }}
              className="group relative overflow-hidden rounded-3xl ring-1 ring-white/10"
            >
              <div className="aspect-[3/4] overflow-hidden">
                <img
                  src={d.img}
                  alt={d.alt}
                  loading="lazy"
                  decoding="async"
                  className="h-full w-full object-cover"
                />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-midnight via-midnight/40 to-transparent" />
              <div className="absolute inset-x-0 bottom-0 p-6">
                <p className="text-[10px] uppercase tracking-[0.25em] text-accent">{d.role}</p>
                <h3 className="mt-1 font-display text-2xl text-ice">{d.name}</h3>
                <p className="mt-2 text-sm text-ice/80">{d.bio}</p>
              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
}
