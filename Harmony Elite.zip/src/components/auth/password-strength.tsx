import { getPasswordChecks, getPasswordStrength } from "@/lib/auth";

export function PasswordStrength({ password }: { password: string }) {
  const checks = getPasswordChecks(password);
  const { score, label } = getPasswordStrength(password);

  if (!password) return null;

  const meterWidth = `${(score / 5) * 100}%`;

  return (
    <div className="space-y-2 rounded-xl border border-input bg-secondary/30 p-3 text-xs text-ice/70">
      <div className="flex items-center justify-between gap-3">
        <span>Password strength</span>
        <span className="text-ice">{label}</span>
      </div>
      <div className="h-1.5 overflow-hidden rounded-full bg-background/70">
        <div
          className="h-full rounded-full bg-accent transition-all duration-300"
          style={{ width: meterWidth }}
        />
      </div>
      <ul className="grid grid-cols-1 gap-1 sm:grid-cols-2">
        <li>{checks.length ? "✓" : "•"} 8+ characters</li>
        <li>{checks.upper ? "✓" : "•"} Uppercase letter</li>
        <li>{checks.lower ? "✓" : "•"} Lowercase letter</li>
        <li>{checks.number ? "✓" : "•"} Number</li>
        <li className="sm:col-span-2">{checks.special ? "✓" : "•"} Special character</li>
      </ul>
    </div>
  );
}