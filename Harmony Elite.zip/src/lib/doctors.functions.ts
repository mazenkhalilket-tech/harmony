import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const EmailSchema = z
  .string()
  .trim()
  .toLowerCase()
  .email("Enter a valid email address.")
  .max(200);

async function assertStaff(userId: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data, error } = await supabaseAdmin
    .from("user_roles")
    .select("id")
    .eq("user_id", userId)
    .in("role", ["admin", "therapist", "reception"])
    .limit(1)
    .maybeSingle();
  if (error || !data) throw new Error("Forbidden");
}

export const listDoctors = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertStaff(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data, error } = await supabaseAdmin
      .from("doctors")
      .select("id, name, title, notification_email, email_linked, email_linked_at, created_at")
      .order("created_at", { ascending: true });
    if (error) {
      console.error("[doctors] list error:", error);
      throw new Error("Could not load doctors.");
    }
    return data ?? [];
  });

export const createDoctor = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z
      .object({
        name: z.string().trim().min(1).max(120),
        title: z.string().trim().max(120).optional(),
      })
      .parse(d),
  )
  .handler(async ({ data, context }) => {
    await assertStaff(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: row, error } = await supabaseAdmin
      .from("doctors")
      .insert({ name: data.name, title: data.title ?? null })
      .select("id")
      .single();
    if (error) {
      console.error("[doctors] create error:", error);
      throw new Error("Could not add doctor.");
    }
    return row;
  });

export const linkDoctorEmail = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z
      .object({ id: z.string().uuid(), email: EmailSchema })
      .parse(d),
  )
  .handler(async ({ data, context }) => {
    await assertStaff(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    // Duplicate guard (case-insensitive)
    const { data: existing } = await supabaseAdmin
      .from("doctors")
      .select("id")
      .ilike("notification_email", data.email)
      .neq("id", data.id)
      .maybeSingle();
    if (existing) {
      throw new Error("This email is already linked to another doctor.");
    }

    const { error } = await supabaseAdmin
      .from("doctors")
      .update({
        notification_email: data.email,
        email_linked: true,
        email_linked_at: new Date().toISOString(),
        email_linked_by: context.userId,
      })
      .eq("id", data.id);
    if (error) {
      if (error.code === "23505") {
        throw new Error("This email is already linked to another doctor.");
      }
      console.error("[doctors] link error:", error);
      throw new Error("Could not link email.");
    }
    return { ok: true };
  });

export const unlinkDoctorEmail = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertStaff(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("doctors")
      .update({
        notification_email: null,
        email_linked: false,
        email_linked_at: null,
        email_linked_by: null,
      })
      .eq("id", data.id);
    if (error) {
      console.error("[doctors] unlink error:", error);
      throw new Error("Could not unlink email.");
    }
    return { ok: true };
  });

export const deleteDoctor = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertStaff(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.from("doctors").delete().eq("id", data.id);
    if (error) {
      console.error("[doctors] delete error:", error);
      throw new Error("Could not remove doctor.");
    }
    return { ok: true };
  });

export const listRecentDoctorEmailLogs = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertStaff(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data, error } = await supabaseAdmin
      .from("doctor_email_logs")
      .select("id, doctor_id, recipient_email, event_type, status, error_message, created_at")
      .order("created_at", { ascending: false })
      .limit(100);
    if (error) {
      console.error("[doctor_email_logs] list error:", error);
      throw new Error("Could not load email logs.");
    }
    return data ?? [];
  });

export const deleteDoctorEmailLog = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertStaff(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.from("doctor_email_logs").delete().eq("id", data.id);
    if (error) {
      console.error("[doctor_email_logs] delete error:", error);
      throw new Error("Could not delete email log.");
    }
    return { ok: true };
  });

export const clearAllDoctorEmailLogs = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertStaff(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("doctor_email_logs")
      .delete()
      .not("id", "is", null);
    if (error) {
      console.error("[doctor_email_logs] clear all error:", error);
      throw new Error("Could not clear email logs.");
    }
    return { ok: true };
  });

export const sendDoctorTest = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertStaff(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: doc } = await supabaseAdmin
      .from("doctors")
      .select("id, name, notification_email, email_linked")
      .eq("id", data.id)
      .maybeSingle();
    if (!doc) throw new Error("Doctor not found.");
    if (!doc.email_linked || !doc.notification_email) {
      throw new Error("Link an email address first.");
    }
    const { sendDoctorTestEmail } = await import(
      "@/lib/email/doctor-notifications.server"
    );
    await sendDoctorTestEmail({
      doctorId: doc.id,
      doctorName: doc.name,
      recipientEmail: doc.notification_email,
    });
    return { ok: true };
  });

// -------- Receptionist settings --------

export const getReceptionistEmail = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertStaff(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data, error } = await supabaseAdmin
      .from("clinic_settings")
      .select("receptionist_email, receptionist_email_linked_at")
      .eq("id", true)
      .maybeSingle();
    if (error) {
      console.error("[clinic_settings] get error:", error);
      throw new Error("Could not load receptionist email.");
    }
    return data ?? { receptionist_email: null, receptionist_email_linked_at: null };
  });

export const linkReceptionistEmail = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ email: EmailSchema }).parse(d))
  .handler(async ({ data, context }) => {
    await assertStaff(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("clinic_settings")
      .upsert({
        id: true,
        receptionist_email: data.email,
        receptionist_email_linked_at: new Date().toISOString(),
        receptionist_email_linked_by: context.userId,
      });
    if (error) {
      console.error("[clinic_settings] link error:", error);
      throw new Error("Could not link receptionist email.");
    }
    return { ok: true };
  });

export const unlinkReceptionistEmail = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertStaff(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("clinic_settings")
      .upsert({
        id: true,
        receptionist_email: null,
        receptionist_email_linked_at: null,
        receptionist_email_linked_by: null,
      });
    if (error) {
      console.error("[clinic_settings] unlink error:", error);
      throw new Error("Could not unlink receptionist email.");
    }
    return { ok: true };
  });

export const sendReceptionistTest = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertStaff(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data } = await supabaseAdmin
      .from("clinic_settings")
      .select("receptionist_email")
      .eq("id", true)
      .maybeSingle();
    if (!data?.receptionist_email) throw new Error("Link a receptionist email first.");
    const { sendDoctorTestEmail } = await import(
      "@/lib/email/doctor-notifications.server"
    );
    await sendDoctorTestEmail({
      doctorId: "00000000-0000-0000-0000-000000000000",
      doctorName: "Receptionist",
      recipientEmail: data.receptionist_email,
    });
    return { ok: true };
  });
