import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export const listPatients = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("patients")
      .select("id, full_name, sex, date_of_birth, phone, primary_complaint, created_at")
      .order("created_at", { ascending: false });
    if (error) {
      console.error("[patients] list error:", error);
      throw new Error("Could not load patients.");
    }
    return data ?? [];
  });

export const createPatient = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z
      .object({
        full_name: z.string().trim().min(1).max(120),
        sex: z.enum(["male", "female"]).optional(),
        phone: z.string().trim().max(40).optional(),
        primary_complaint: z.string().trim().max(500).optional(),
      })
      .parse(d),
  )
  .handler(async ({ data, context }) => {
    const { data: row, error } = await context.supabase
      .from("patients")
      .insert({ ...data, created_by: context.userId })
      .select("id")
      .single();
    if (error) {
      console.error("[patients] create error:", error);
      throw new Error("Could not create patient.");
    }
    return row;
  });

export const deletePatient = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("patients").delete().eq("id", data.id);
    if (error) {
      console.error("[patients] delete error:", error);
      throw new Error("Could not delete patient.");
    }
    return { ok: true };
  });

export const deleteAllPatients = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { error } = await context.supabase
      .from("patients")
      .delete()
      .not("id", "is", null);
    if (error) {
      console.error("[patients] delete-all error:", error);
      throw new Error("Could not clear patients.");
    }
    return { ok: true };
  });
