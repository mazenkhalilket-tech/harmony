// Server-only. Never imported from client modules.
const pw = process.env.STAFF_SECONDARY_PASSWORD;
if (!pw) {
  throw new Error(
    "STAFF_SECONDARY_PASSWORD env var is required. Configure it in the backend secrets.",
  );
}
export const STAFF_SECONDARY_PASSWORD: string = pw;
