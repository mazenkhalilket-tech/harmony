import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { CLINIC, SERVICES, SLOTS } from "@/lib/clinic";

const BRANCH_BY_ID = new Map<string, string>(CLINIC.branches.map((b) => [b.id, b.label]));
const BRANCH_IDS = CLINIC.branches.map((b) => b.id) as [string, ...string[]];

const BookingSchema = z
  .object({
    branch_id: z.enum(BRANCH_IDS as unknown as [string, ...string[]]),
    branch_label: z.string().min(1).max(120),
    service: z.enum(SERVICES as unknown as [string, ...string[]]),
    booking_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Invalid date"),
    booking_time: z.enum(SLOTS as unknown as [string, ...string[]]),
    full_name: z.string().trim().min(2).max(120),
    gender: z.enum(["male", "female", "other"]),
    phone: z.string().trim().min(6).max(30),
    email: z
      .union([
        z.string().trim().toLowerCase().email().max(200),
        z.literal(""),
      ])
      .optional()
      .transform((v) => (v ? v : undefined)),
    notes: z.string().trim().max(500).optional(),
    doctor_id: z.string().uuid().optional().nullable(),
  })
  .transform((d) => ({
    ...d,
    branch_label: BRANCH_BY_ID.get(d.branch_id) ?? d.branch_label,
    doctor_id: d.doctor_id ?? null,
    email: d.email ?? null,
  }));


async function assertStaff(userId: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data, error } = await supabaseAdmin
    .from("user_roles")
    .select("id")
    .eq("user_id", userId)
    .in("role", ["admin", "therapist", "reception"])
    .limit(1)
    .maybeSingle();
  if (error || !data) {
    throw new Error("Forbidden");
  }
}

export const createBooking = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => BookingSchema.parse(d))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    // Double-booking guard
    const { data: existing, error: checkErr } = await supabaseAdmin
      .from("bookings")
      .select("id")
      .eq("branch_id", data.branch_id)
      .eq("booking_date", data.booking_date)
      .eq("booking_time", data.booking_time)
      .neq("status", "cancelled")
      .maybeSingle();
    if (checkErr) {
      console.error("[bookings] check error:", checkErr);
      throw new Error("Could not check that slot. Please try again.");
    }
    if (existing) {
      throw new Error("That slot was just booked. Please pick another time.");
    }

    // Validate doctor_id exists; if not, drop it instead of failing the booking.
    if (data.doctor_id) {
      const { data: doc } = await supabaseAdmin
        .from("doctors")
        .select("id")
        .eq("id", data.doctor_id)
        .maybeSingle();
      if (!doc) {
        (data as { doctor_id: string | null }).doctor_id = null;
      }

    }


    const { data: row, error } = await supabaseAdmin
      .from("bookings")
      .insert(data)
      .select("id")
      .single();
    if (error) {
      if (error.code === "23505") {
        throw new Error("That slot was just booked. Please pick another time.");
      }
      console.error("[bookings] insert error:", error);
      throw new Error("Could not create booking. Please try again.");
    }

    // Fire-and-forget: notify the linked doctor (if any) and the receptionist by email.
    try {
      const { data: settings } = await supabaseAdmin
        .from("clinic_settings")
        .select("receptionist_email")
        .eq("id", true)
        .maybeSingle();

      let doctor: { id: string; name: string; notification_email: string } | null = null;
      if (data.doctor_id) {
        const { data: doc } = await supabaseAdmin
          .from("doctors")
          .select("id, name, notification_email, email_linked")
          .eq("id", data.doctor_id)
          .maybeSingle();
        if (doc?.email_linked && doc.notification_email) {
          doctor = { id: doc.id, name: doc.name, notification_email: doc.notification_email };
        }
      }

      const recipients: Array<{ id: string; name: string; email: string }> = [];
      if (doctor) {
        recipients.push({ id: doctor.id, name: doctor.name, email: doctor.notification_email });
      }
      if (settings?.receptionist_email) {
        recipients.push({
          id: "00000000-0000-0000-0000-000000000000",
          name: "Receptionist",
          email: settings.receptionist_email,
        });
      }

      if (recipients.length > 0) {
        const { sendDoctorBookingEmail } = await import(
          "@/lib/email/doctor-notifications.server"
        );
        for (const r of recipients) {
          try {
            await sendDoctorBookingEmail({
              doctorId: r.id,
              doctorName: doctor?.name ?? r.name,
              recipientEmail: r.email,
              bookingId: row.id,
              status: "pending",
              patientName: data.full_name,
              phone: data.phone,
              email: data.email ?? null,
              gender: data.gender,
              service: data.service,
              branch: data.branch_label,
              bookingDate: data.booking_date,
              bookingTime: data.booking_time,
              notes: data.notes ?? null,
            });
          } catch (e) {
            console.error("[bookings] notify error:", r.email, e);
          }
        }
      }
    } catch (e) {
      console.error("[bookings] notify outer error:", e);
    }


    return { id: row.id };
  });

// Public lookup of doctor names (for the booking form). No emails returned.
export const listDoctorsPublic = createServerFn({ method: "GET" }).handler(async () => {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data, error } = await supabaseAdmin
    .from("doctors")
    .select("id, name, title")
    .order("name", { ascending: true });
  if (error) {
    console.error("[doctors] public list error:", error);
    return [];
  }
  return data ?? [];
});

const TakenSchema = z.object({
  branch_id: z.enum(BRANCH_IDS as unknown as [string, ...string[]]),
  booking_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
});


export const getTakenSlots = createServerFn({ method: "GET" })
  .inputValidator((d: unknown) => TakenSchema.parse(d))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: rows, error } = await supabaseAdmin
      .from("bookings")
      .select("booking_time")
      .eq("branch_id", data.branch_id)
      .eq("booking_date", data.booking_date)
      .neq("status", "cancelled");
    if (error) {
      console.error("[bookings] taken slots error:", error);
      throw new Error("Could not load availability. Please try again.");
    }
    return { times: (rows ?? []).map((r) => r.booking_time as string) };
  });

export const listBookings = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertStaff(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data, error } = await supabaseAdmin
      .from("bookings")
      .select("*")
      .order("booking_date", { ascending: false })
      .order("booking_time", { ascending: false })
      .limit(500);
    if (error) {
      console.error("[bookings] list error:", error);
      throw new Error("Could not load bookings.");
    }
    return data ?? [];
  });

const StatusSchema = z.object({
  id: z.string().uuid(),
  status: z.enum(["pending", "confirmed", "cancelled", "completed"]),
});

export const updateBookingStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => StatusSchema.parse(d))
  .handler(async ({ data, context }) => {
    await assertStaff(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: updated, error } = await supabaseAdmin
      .from("bookings")
      .update({ status: data.status })
      .eq("id", data.id)
      .select("*")
      .single();
    if (error) {
      if (error.code === "23505") {
        throw new Error("Another active booking already exists for that slot.");
      }
      console.error("[bookings] update error:", error);
      throw new Error("Could not update booking.");
    }

    // Fire-and-forget: notify the linked doctor and the receptionist about the status change.
    try {
      const { data: settings } = await supabaseAdmin
        .from("clinic_settings")
        .select("receptionist_email")
        .eq("id", true)
        .maybeSingle();

      let doctor: { id: string; name: string; notification_email: string } | null = null;
      if (updated?.doctor_id) {
        const { data: doc } = await supabaseAdmin
          .from("doctors")
          .select("id, name, notification_email, email_linked")
          .eq("id", updated.doctor_id)
          .maybeSingle();
        if (doc?.email_linked && doc.notification_email) {
          doctor = { id: doc.id, name: doc.name, notification_email: doc.notification_email };
        }
      }

      const recipients: Array<{ id: string; name: string; email: string }> = [];
      if (doctor) {
        recipients.push({ id: doctor.id, name: doctor.name, email: doctor.notification_email });
      }
      if (settings?.receptionist_email) {
        recipients.push({
          id: "00000000-0000-0000-0000-000000000000",
          name: "Receptionist",
          email: settings.receptionist_email,
        });
      }

      if (recipients.length > 0 && updated) {
        const { sendDoctorBookingEmail } = await import(
          "@/lib/email/doctor-notifications.server"
        );
        for (const r of recipients) {
          try {
            await sendDoctorBookingEmail({
              doctorId: r.id,
              doctorName: doctor?.name ?? r.name,
              recipientEmail: r.email,
              bookingId: updated.id,
              status: data.status,
              patientName: updated.full_name,
              phone: updated.phone,
              email: (updated as { email?: string | null }).email ?? null,
              gender: updated.gender,
              service: updated.service,
              branch: updated.branch_label,
              bookingDate: updated.booking_date,
              bookingTime: updated.booking_time,
              notes: updated.notes ?? null,
            });
          } catch (e) {
            console.error("[bookings] status notify error:", r.email, e);
          }
        }
      }
    } catch (e) {
      console.error("[bookings] status notify outer error:", e);
    }


    return { ok: true };
  });

export const deleteBooking = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertStaff(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.from("bookings").delete().eq("id", data.id);
    if (error) {
      console.error("[bookings] delete error:", error);
      throw new Error("Could not remove booking.");
    }
    return { ok: true };
  });

export const deleteAllBookings = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertStaff(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("bookings")
      .delete()
      .not("id", "is", null);
    if (error) {
      console.error("[bookings] clear error:", error);
      throw new Error("Could not clear bookings.");
    }
    return { ok: true };
  });
