import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export const verifyStaffSecondary = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z.object({ password: z.string().min(1).max(200) }).parse(d),
  )
  .handler(async ({ data }) => {
    const { STAFF_SECONDARY_PASSWORD } = await import("./staff-gate.server");
    const a = Buffer.from(data.password);
    const b = Buffer.from(STAFF_SECONDARY_PASSWORD);
    let ok = a.length === b.length;
    const len = Math.max(a.length, b.length);
    let diff = a.length ^ b.length;
    for (let i = 0; i < len; i++) diff |= (a[i] ?? 0) ^ (b[i] ?? 0);
    ok = diff === 0;
    if (!ok) throw new Error("Incorrect staff password.");
    return { ok: true };
  });
