import React from "react";
import {
  Body,
  Container,
  Head,
  Heading,
  Hr,
  Html,
  Preview,
  Section,
  Text,
} from "@react-email/components";
import type { TemplateEntry } from "./registry";

interface Props {
  doctorName?: string;
  status?: string;
  statusLabel?: string;
  patientName?: string;
  phone?: string;
  email?: string;
  gender?: string;
  service?: string;
  branch?: string;
  bookingDate?: string;
  bookingTime?: string;
  notes?: string;
}

const STATUS_COPY: Record<string, { headline: string; intro: string; badge: string }> = {
  pending: {
    headline: "New Booking Received — Pending Approval",
    intro: "A new booking has been submitted and is awaiting approval.",
    badge: "#b45309",
  },
  confirmed: {
    headline: "Booking Confirmed",
    intro: "The following booking has been confirmed.",
    badge: "#047857",
  },
  completed: {
    headline: "Booking Completed",
    intro: "The following booking has been marked as completed.",
    badge: "#0369a1",
  },
  cancelled: {
    headline: "Booking Cancelled",
    intro: "The following booking has been cancelled.",
    badge: "#b91c1c",
  },
};

const Email = ({
  doctorName = "Doctor",
  status = "pending",
  statusLabel,
  patientName = "—",
  phone = "—",
  email,
  gender = "—",
  service = "—",
  branch = "—",
  bookingDate = "—",
  bookingTime = "—",
  notes,
}: Props) => {
  const copy = STATUS_COPY[status] ?? STATUS_COPY.pending;
  const label = statusLabel ?? status.charAt(0).toUpperCase() + status.slice(1);
  return (
    <Html lang="en" dir="ltr">
      <Head />
      <Preview>{copy.headline} — {patientName} · {bookingDate} {bookingTime}</Preview>
      <Body style={main}>
        <Container style={container}>
          <Heading style={h1}>{copy.headline}</Heading>
          <Text style={text}>Dear {doctorName},</Text>
          <Text style={text}>{copy.intro}</Text>

          <Section style={card}>
            <Row label="Booking Status" value={label} valueStyle={{ color: copy.badge, fontWeight: 700 }} />
            <Row label="Patient name" value={patientName} />
            <Row label="Phone" value={phone} />
            {email ? <Row label="Email" value={email} /> : null}
            <Row label="Gender" value={gender} />
            <Row label="Service" value={service} />
            <Row label="Branch" value={branch} />
            <Row label="Date" value={bookingDate} />
            <Row label="Time" value={bookingTime} />
            {notes ? <Row label="Notes" value={notes} /> : null}
          </Section>

          <Hr style={hr} />
          <Text style={muted}>
            You're receiving this because your email is linked to this doctor profile in the Staff Portal.
          </Text>
        </Container>
      </Body>
    </Html>
  );
};

const Row = ({
  label,
  value,
  valueStyle,
}: {
  label: string;
  value: string;
  valueStyle?: React.CSSProperties;
}) => (
  <Section style={{ padding: "6px 0" }}>
    <Text style={rowLabel}>{label}</Text>
    <Text style={{ ...rowValue, ...(valueStyle ?? {}) }}>{value}</Text>
  </Section>
);

const main = { backgroundColor: "#ffffff", fontFamily: "Arial, sans-serif" };
const container = { padding: "24px", maxWidth: "560px" };
const h1 = { fontSize: "20px", color: "#0b2545", margin: "0 0 12px" };
const text = { fontSize: "14px", color: "#1f2937", lineHeight: "22px" };
const card = {
  backgroundColor: "#f8fafc",
  border: "1px solid #e2e8f0",
  borderRadius: "12px",
  padding: "16px 18px",
  margin: "16px 0",
};
const rowLabel = {
  fontSize: "11px",
  textTransform: "uppercase" as const,
  letterSpacing: "0.08em",
  color: "#64748b",
  margin: "0",
};
const rowValue = { fontSize: "14px", color: "#0f172a", margin: "2px 0 0", fontWeight: 500 };
const hr = { borderColor: "#e2e8f0", margin: "20px 0" };
const muted = { fontSize: "12px", color: "#64748b" };

export const template = {
  component: Email,
  subject: (d: Record<string, any>) => {
    const status = (d.status ?? "pending") as string;
    if (status === "confirmed") return "Booking Confirmed";
    if (status === "completed") return "Booking Completed";
    if (status === "cancelled") return "Booking Cancelled";
    return "New Booking Received - Pending Approval";
  },
  displayName: "Doctor booking notification",
  previewData: {
    doctorName: "Dr. Amr",
    status: "pending",
    patientName: "Jane Doe",
    phone: "+20 100 000 0000",
    email: "jane@example.com",
    gender: "female",
    service: "Initial Assessment",
    branch: "Cairo Branch",
    bookingDate: "2026-06-20",
    bookingTime: "10:00",
  },
} satisfies TemplateEntry;
