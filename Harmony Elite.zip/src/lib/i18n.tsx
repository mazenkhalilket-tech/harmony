import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

export type Lang = "en" | "ar";

type Dict = {
  dir: "ltr" | "rtl";
  nav: { services: string; doctors: string; locations: string; booking: string; staff: string; book: string; menu: string; close: string; call: string };
  hero: {
    badge: string;
    titleA: string;
    titleB: string;
    sub: string;
    bookCta: string;
    exploreCta: string;
    stats: { k: string; v: string }[];
  };
  services: {
    eyebrow: string;
    title: string;
    sub: string;
    signature: string;
    items: { title: string; items: string[] }[];
  };
  doctors: {
    eyebrow: string;
    title: string;
    sub: string;
    list: { name: string; role: string; bio: string }[];
  };
  reviews: { eyebrow: string; title: string; playAria: string };
  booking: {
    eyebrow: string;
    title: string;
    sub: string;
    branch: string;
    service: string;
    date: string;
    time: string;
    fullName: string;
    fullNamePh: string;
    gender: string;
    male: string;
    female: string;
    other: string;
    phone: string;
    phonePh: string;
    submit: (d: string, t: string) => string;
    sending: string;
    booked: string;
    note: string;
    successTitle: string;
    successBody: (first: string, phone: string, svc: string, date: string, time: string) => string;
    successCta: string;
    toast: { ok: string; err: string; needName: string; needPhone: string };
  };
  locations: { eyebrow: string; title: string; brand: string; call: string; whatsapp: string; directions: string };
  footer: { tagline: string; about: string; rights: string };
  branchPicker: {
    callTitle: string;
    bookTitle: string;
    callSub: string;
    bookSub: string;
    waMessage: (label: string) => string;
    close: string;
  };
  language: { en: string; ar: string; switchTo: string };
};

const en: Dict = {
  dir: "ltr",
  nav: {
    services: "Services",
    doctors: "Doctors",
    locations: "Locations",
    booking: "Booking",
    staff: "Staff Sign In",
    book: "Book Now",
    menu: "Menu",
    close: "Close menu",
    call: "Call",
  },
  hero: {
    badge: "Elite Recovery · New Cairo",
    titleA: "Harmony Physiotherapy",
    titleB: "Turn Your Pain Into Power.",
    sub: "Harmony is an elite physiotherapy practice specialising in advanced lymphatic massage and adult rehabilitation. Precise hands. Quiet rooms. Real recovery — engineered around you.",
    bookCta: "Book Appointment",
    exploreCta: "Explore Services",
    stats: [
      { k: "2", v: "Premium branches" },
      { k: "1:1", v: "Personalised care" },
      { k: "100%", v: "Adult focus" },
    ],
  },
  services: {
    eyebrow: "What we do",
    title: "Adult physiotherapy, refined to a craft.",
    sub: "Every protocol is led by senior clinicians and tailored to one body — yours. Lymphatic care is our signature.",
    signature: "Our signature",
    items: [
      { title: "Manual Therapy", items: ["Trigger Point Therapy", "Joint Mobilization", "Muscle Release Techniques"] },
      {
        title: "Lymphatic Massage",
        items: [
          "Improves circulation and natural detoxification",
          "Reduces post-surgical and post-cosmetic swelling",
          "Eases water retention, bloating and heavy-leg sensation",
          "Calms the nervous system for deep, restorative relaxation",
          "Delivered by senior-trained therapists using specialized techniques",
        ],
      },
      {
        title: "Posture Correction Programs",
        items: [
          "Corrects neck, back and mild scoliosis posture issues",
          "Reduces tension headaches and shoulder/neck strain from poor posture",
          "Personalized home-exercise plans for long-term results",
        ],
      },
      { title: "Recovery & Rehabilitation Programs", items: ["Post-Operative Rehabilitation"] },
      {
        title: "Specialized Medical Assessment",
        items: ["Comprehensive Evaluation of the Condition", "Diagnosis of the Cause of Pain", "Individualized Treatment Plan"],
      },
      { title: "Spinal Column Treatment", items: ["Neck and Back Pain", "Herniated Discs", "Sciatica (Sciatic Nerve Pain)"] },
      { title: "Sports Injury Rehabilitation", items: ["Strengthening and Recovery", "Improved Flexibility and Motor Function"] },
    ],
  },
  doctors: {
    eyebrow: "Our doctors",
    title: "Meet the minds behind Harmony.",
    sub: "Care, expertise, and recovery — together.",
    list: [
      { name: "Dr. Amr Eltourky", role: "Founder & CEO", bio: "Leading every recovery journey with experience and vision." },
      { name: "Dr. Anan Atef", role: "Senior Physiotherapist", bio: "Dedicated to helping you move better and feel stronger." },
      { name: "Dr. Passant Elseoudie", role: "Senior Physiotherapist", bio: "Focused on care, comfort, and lasting recovery." },
    ],
  },
  reviews: { eyebrow: "Real patients", title: "The work speaks for itself.", playAria: "Play video with sound" },
  booking: {
    eyebrow: "Booking",
    title: "Reserve your session.",
    sub: "Pick your branch, service, date and time — we'll confirm your appointment shortly.",
    branch: "Branch",
    service: "Service",
    date: "Date",
    time: "Time",
    fullName: "Full name",
    fullNamePh: "Your full name",
    gender: "Gender",
    male: "Male",
    female: "Female",
    other: "Prefer not to say",
    phone: "Phone number",
    phonePh: "e.g. 0150 000 0000",
    submit: (d, t) => `Book ${d} · ${t}`,
    sending: "Sending…",
    booked: "booked",
    note: "We'll contact you on the phone number you provide to confirm your appointment.",
    successTitle: "Booking received",
    successBody: (first, phone, svc, date, time) =>
      `Thank you ${first} — our team will contact you on ${phone} to confirm your ${svc} session on ${date} at ${time}.`,
    successCta: "Book another session",
    toast: {
      ok: "Booking received — we'll confirm shortly.",
      err: "Could not submit booking",
      needName: "Please enter your name",
      needPhone: "Please enter a valid phone number",
    },
  },
  locations: {
    eyebrow: "Visit us",
    title: "Two branches. One standard.",
    brand: "Harmony",
    call: "Call",
    whatsapp: "WhatsApp",
    directions: "Directions",
  },
  footer: {
    tagline: "Turn Your Pain Into Power",
    about: "Elite adult physiotherapy and specialist lymphatic care in New Cairo. Two branches. One standard of excellence.",
    rights: "All rights reserved.",
  },
  branchPicker: {
    callTitle: "Which branch would you like to call?",
    bookTitle: "Which branch would you like to book at?",
    callSub: "Tap a branch to call directly.",
    bookSub: "We'll open WhatsApp with the right team ready to confirm your slot.",
    waMessage: (label) => `Hello Harmony — I'd like to book an appointment at the ${label} branch.`,
    close: "Close",
  },
  language: { en: "English", ar: "العربية", switchTo: "العربية" },
};

const ar: Dict = {
  dir: "rtl",
  nav: {
    services: "خدماتنا",
    doctors: "الأطباء",
    locations: "فروعنا",
    booking: "احجز",
    staff: "دخول الفريق",
    book: "احجز الآن",
    menu: "القائمة",
    close: "إغلاق القائمة",
    call: "اتصل",
  },
  hero: {
    badge: "تعافي راقي · التجمع الخامس",
    titleA: "هارموني للعلاج الطبيعي",
    titleB: "خلّي ألمك يبقى قوتك.",
    sub: "هارموني عيادة علاج طبيعي متخصصة في الماساچ الليمفاوي المتقدم وإعادة تأهيل الكبار. أيادي محترفة، أجواء هادية، وتعافي حقيقي مفصّل على جسمك إنت بالذات.",
    bookCta: "احجز موعدك",
    exploreCta: "اعرف خدماتنا",
    stats: [
      { k: "2", v: "فرعين راقيين" },
      { k: "1:1", v: "رعاية شخصية" },
      { k: "100%", v: "للكبار فقط" },
    ],
  },
  services: {
    eyebrow: "بنعمل إيه",
    title: "علاج طبيعي للكبار، بصنعة محترفة.",
    sub: "كل بروتوكول علاج بنحدده مع كبار الأخصائيين ومفصّل على جسمك إنت. والماساچ الليمفاوي هو بصمتنا المميزة.",
    signature: "بصمتنا المميزة",
    items: [
      {
        title: "العلاج اليدوي",
        items: ["علاج نقاط الزناد العضلية", "تحريك المفاصل", "تقنيات إرخاء العضلات"],
      },
      {
        title: "الماساچ الليمفاوي",
        items: [
          "بيحسّن الدورة الدموية ويساعد الجسم على التخلص من السموم",
          "بيقلل التورم بعد العمليات الجراحية وعمليات التجميل",
          "بيخفف احتباس المياه والانتفاخ وتقل القدمين",
          "بيهدّي الجهاز العصبي ويديك إحساس عميق بالاسترخاء",
          "بيتعمل على يد أخصائيين كبار بتقنيات متخصصة",
        ],
      },
      {
        title: "برامج تصحيح القوام",
        items: [
          "تصحيح مشاكل قوام الرقبة والظهر وحالات الجنف البسيطة",
          "تقليل صداع التوتر وآلام الرقبة والكتف الناتجة عن وضع الجسم الخاطئ",
          "خطة تمارين منزلية مخصصة لنتائج طويلة المدى",
        ],
      },
      { title: "برامج التعافي وإعادة التأهيل", items: ["إعادة التأهيل بعد العمليات"] },
      {
        title: "تقييم طبي متخصص",
        items: ["تقييم شامل للحالة", "تشخيص سبب الألم", "خطة علاجية مفصّلة لك"],
      },
      {
        title: "علاج العمود الفقري",
        items: ["آلام الرقبة والظهر", "الانزلاق الغضروفي", "عرق النسا"],
      },
      {
        title: "إعادة تأهيل الإصابات الرياضية",
        items: ["تقوية وتعافي", "تحسين المرونة والأداء الحركي"],
      },
    ],
  },
  doctors: {
    eyebrow: "أطباؤنا",
    title: "اتعرّف على العقول ورا هارموني.",
    sub: "اهتمام، خبرة، وتعافي — كله مع بعض.",
    list: [
      { name: "د. عمرو الطورقي", role: "المؤسس والرئيس التنفيذي", bio: "بيقود كل رحلة تعافي بخبرة ورؤية واضحة." },
      { name: "د. عنان عاطف", role: "أخصائي علاج طبيعي أول", bio: "بيساعدك تتحرك أحسن وتحس بقوة أكبر." },
      { name: "د. باسنت السعودي", role: "أخصائية علاج طبيعي أول", bio: "بتركّز على الراحة والعناية والتعافي اللي يدوم." },
    ],
  },
  reviews: { eyebrow: "مرضى حقيقيون", title: "الشغل بيتكلم عن نفسه.", playAria: "تشغيل الفيديو بالصوت" },
  booking: {
    eyebrow: "الحجز",
    title: "احجز جلستك.",
    sub: "اختار الفرع والخدمة واليوم والميعاد — وهنأكدلك الحجز في أقرب وقت.",
    branch: "الفرع",
    service: "الخدمة",
    date: "التاريخ",
    time: "الميعاد",
    fullName: "الاسم بالكامل",
    fullNamePh: "اكتب اسمك بالكامل",
    gender: "النوع",
    male: "ذكر",
    female: "أنثى",
    other: "أفضّل عدم الإفصاح",
    phone: "رقم الموبايل",
    phonePh: "مثال: ٠١٥٠ ٠٠٠ ٠٠٠٠",
    submit: (d, t) => `احجز ${d} · ${t}`,
    sending: "جاري الإرسال…",
    booked: "محجوز",
    note: "هنتواصل معاك على رقم الموبايل اللي كتبته عشان نأكد ميعادك.",
    successTitle: "تم استلام الحجز",
    successBody: (first, phone, svc, date, time) =>
      `شكراً ${first} — فريقنا هيتواصل معاك على ${phone} عشان يأكد جلسة ${svc} يوم ${date} الساعة ${time}.`,
    successCta: "احجز جلسة تانية",
    toast: {
      ok: "تم استلام حجزك — هنأكدلك قريب.",
      err: "ما قدرناش نسجّل الحجز",
      needName: "من فضلك اكتب اسمك",
      needPhone: "من فضلك اكتب رقم موبايل صحيح",
    },
  },
  locations: {
    eyebrow: "زورنا",
    title: "فرعين. ومستوى واحد.",
    brand: "هارموني",
    call: "اتصل",
    whatsapp: "واتساب",
    directions: "الاتجاهات",
  },
  footer: {
    tagline: "خلّي ألمك يبقى قوتك",
    about: "علاج طبيعي راقي للكبار ورعاية ليمفاوية متخصصة في القاهرة الجديدة. فرعين. ومستوى واحد من التميز.",
    rights: "جميع الحقوق محفوظة.",
  },
  branchPicker: {
    callTitle: "تحب تتصل بأي فرع؟",
    bookTitle: "تحب تحجز في أي فرع؟",
    callSub: "اضغط على الفرع للاتصال مباشرة.",
    bookSub: "هنفتحلك واتساب مع الفريق المناسب لتأكيد ميعادك.",
    waMessage: (label) => `أهلاً هارموني — حابب أحجز موعد في فرع ${label}.`,
    close: "إغلاق",
  },
  language: { en: "English", ar: "العربية", switchTo: "English" },
};

const DICTS: Record<Lang, Dict> = { en, ar };

type Ctx = { lang: Lang; setLang: (l: Lang) => void; t: Dict; dir: "ltr" | "rtl" };
const I18nContext = createContext<Ctx | null>(null);

const STORAGE_KEY = "harmony.lang";

export function I18nProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>("en");

  useEffect(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY) as Lang | null;
      if (saved === "en" || saved === "ar") setLangState(saved);
    } catch {}
  }, []);

  useEffect(() => {
    const dir = DICTS[lang].dir;
    if (typeof document !== "undefined") {
      document.documentElement.lang = lang;
      document.documentElement.dir = dir;
    }
  }, [lang]);

  const setLang = (l: Lang) => {
    setLangState(l);
    try {
      localStorage.setItem(STORAGE_KEY, l);
    } catch {}
  };

  return (
    <I18nContext.Provider value={{ lang, setLang, t: DICTS[lang], dir: DICTS[lang].dir }}>
      {children}
    </I18nContext.Provider>
  );
}

export function useI18n() {
  const ctx = useContext(I18nContext);
  if (!ctx) throw new Error("useI18n must be used within I18nProvider");
  return ctx;
}

export function LanguageToggle({ className = "" }: { className?: string }) {
  const { lang, setLang, t } = useI18n();
  const next: Lang = lang === "en" ? "ar" : "en";
  const label = lang === "en" ? `التبديل إلى ${t.language.switchTo}` : `Switch to ${t.language.switchTo}`;
  return (
    <button
      type="button"
      onClick={() => setLang(next)}
      aria-label={label}
      title={label}
      className={`inline-flex items-center gap-1.5 rounded-full border border-white/15 px-3 py-1.5 text-xs font-medium text-ice transition hover:bg-white/5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/70 ${className}`}
    >
      <span aria-hidden>{lang === "en" ? "🇪🇬" : "🇬🇧"}</span>
      <span>{t.language.switchTo}</span>
    </button>
  );
}

