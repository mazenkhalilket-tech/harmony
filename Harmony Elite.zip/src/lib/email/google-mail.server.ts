const GATEWAY_URL = 'https://connector-gateway.lovable.dev/google_mail/gmail/v1'

function getGoogleMailApiKey() {
  const entry = Object.entries(process.env).find(
    ([key, value]) => /^GOOGLE_MAIL_API_KEY(?:_\d+)?$/.test(key) && typeof value === 'string' && value.length > 0,
  )

  if (!entry?.[1]) {
    throw new Error('Gmail is not linked to this project. Approve the Gmail connector for this project first.')
  }

  return entry[1]
}

function toBase64Url(input: string) {
  return Buffer.from(input)
    .toString('base64')
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/g, '')
}

function buildRawMessage(input: {
  to: string
  subject: string
  text: string
  html: string
  replyTo?: string
}) {
  const boundary = `boundary_${crypto.randomUUID()}`
  const headers = [
    `To: ${input.to}`,
    `Subject: ${input.subject}`,
    'MIME-Version: 1.0',
    ...(input.replyTo ? [`Reply-To: ${input.replyTo}`] : []),
    `Content-Type: multipart/alternative; boundary="${boundary}"`,
  ]

  const body = [
    `--${boundary}`,
    'Content-Type: text/plain; charset="UTF-8"',
    'Content-Transfer-Encoding: 7bit',
    '',
    input.text,
    '',
    `--${boundary}`,
    'Content-Type: text/html; charset="UTF-8"',
    'Content-Transfer-Encoding: 7bit',
    '',
    input.html,
    '',
    `--${boundary}--`,
    '',
  ]

  return toBase64Url([...headers, '', ...body].join('\r\n'))
}

export async function sendViaGoogleMail(input: {
  to: string
  subject: string
  text: string
  html: string
  replyTo?: string
}) {
  const lovableApiKey = process.env.LOVABLE_API_KEY
  if (!lovableApiKey) {
    throw new Error('Missing Lovable API key for Gmail sending.')
  }

  const googleMailApiKey = getGoogleMailApiKey()
  const raw = buildRawMessage(input)

  const response = await fetch(`${GATEWAY_URL}/users/me/messages/send`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${lovableApiKey}`,
      'X-Connection-Api-Key': googleMailApiKey,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ raw }),
  })

  if (!response.ok) {
    const bodyText = await response.text()
    throw new Error(`Gmail send failed (${response.status}): ${bodyText.slice(0, 800)}`)
  }

  return response.json()
}