// Server-only helper to enqueue doctor booking notification emails (for new
// bookings AND status changes) via the transactional email pipeline.
import * as React from "react";
import { render } from "@react-email/components";
import { TEMPLATES } from "@/lib/email-templates/registry";
import { sendViaGoogleMail } from "@/lib/email/google-mail.server";

const SITE_NAME = "Harmony Elite Care";
const REPLY_TO = "no-reply@auth.lovable.cloud";

function token32(): string {
  const b = new Uint8Array(32);
  crypto.getRandomValues(b);
  return Array.from(b).map((x) => x.toString(16).padStart(2, "0")).join("");
}

export type BookingStatus = "pending" | "confirmed" | "completed" | "cancelled";

export interface DoctorBookingEmailInput {
  doctorId: string;
  doctorName: string;
  recipientEmail: string;
  bookingId: string;
  status: BookingStatus;
  patientName: string;
  phone: string;
  email?: string | null;
  gender: string;
  service: string;
  branch: string;
  bookingDate: string;
  bookingTime: string;
  notes?: string | null;
}

const SUBJECT_BY_STATUS: Record<BookingStatus, string> = {
  pending: "New Booking Received - Pending Approval",
  confirmed: "Booking Confirmed",
  completed: "Booking Completed",
  cancelled: "Booking Cancelled",
};

export async function sendDoctorBookingEmail(input: DoctorBookingEmailInput) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

  const template = TEMPLATES["doctor-booking-notification"];
  if (!template) throw new Error("Template missing");

  const recipient = input.recipientEmail.toLowerCase();
  const eventType = `booking_${input.status}`;

  // Duplicate guard — skip if we already queued/sent this status for this booking + recipient.
  const { data: dup } = await supabaseAdmin
    .from("doctor_email_logs")
    .select("id")
    .eq("booking_id", input.bookingId)
    .eq("event_type", eventType)
    .eq("recipient_email", recipient)
    .in("status", ["queued", "sent"])
    .maybeSingle();
  if (dup) return { sent: false, reason: "duplicate" as const };

  // Suppression check
  const { data: suppressed } = await supabaseAdmin
    .from("suppressed_emails")
    .select("id")
    .eq("email", recipient)
    .maybeSingle();
  if (suppressed) {
    await supabaseAdmin.from("doctor_email_logs").insert({
      doctor_id: input.doctorId,
      recipient_email: recipient,
      booking_id: input.bookingId,
      event_type: eventType,
      status: "suppressed",
    });
    return { sent: false, reason: "suppressed" as const };
  }

  // Get-or-create unsubscribe token
  let unsubToken: string;
  const { data: existing } = await supabaseAdmin
    .from("email_unsubscribe_tokens")
    .select("token, used_at")
    .eq("email", recipient)
    .maybeSingle();
  if (existing?.token && !existing.used_at) {
    unsubToken = existing.token;
  } else {
    unsubToken = token32();
    await supabaseAdmin
      .from("email_unsubscribe_tokens")
      .upsert({ token: unsubToken, email: recipient }, { onConflict: "email", ignoreDuplicates: true });
    const { data: re } = await supabaseAdmin
      .from("email_unsubscribe_tokens")
      .select("token")
      .eq("email", recipient)
      .maybeSingle();
    if (re?.token) unsubToken = re.token;
  }

  const templateData = {
    doctorName: input.doctorName,
    status: input.status,
    patientName: input.patientName,
    phone: input.phone,
    email: input.email ?? undefined,
    gender: input.gender,
    service: input.service,
    branch: input.branch,
    bookingDate: input.bookingDate,
    bookingTime: input.bookingTime,
    notes: input.notes ?? undefined,
  };

  const element = React.createElement(template.component, templateData);
  const html = await render(element);
  const text = await render(element, { plainText: true });
  const subject = SUBJECT_BY_STATUS[input.status];

  const messageId = crypto.randomUUID();
  const label = `doctor-booking-${input.status}`;

  await supabaseAdmin.from("email_send_log").insert({
    message_id: messageId,
    template_name: label,
    recipient_email: recipient,
    status: "pending",
  });

  try {
    await sendViaGoogleMail({
      to: recipient,
      subject,
      html,
      text,
      replyTo: REPLY_TO,
    });

    await supabaseAdmin.from("email_send_log").insert({
      message_id: messageId,
      template_name: label,
      recipient_email: recipient,
      status: "sent",
    });

    await supabaseAdmin.from("doctor_email_logs").insert({
      doctor_id: input.doctorId,
      recipient_email: recipient,
      booking_id: input.bookingId,
      event_type: eventType,
      status: "sent",
      error_message: null,
    });

    return { sent: true };
  } catch (error) {
    const message = String(error instanceof Error ? error.message : error);
    await supabaseAdmin.from("email_send_log").insert({
      message_id: messageId,
      template_name: label,
      recipient_email: recipient,
      status: "failed",
      error_message: message,
    });

    await supabaseAdmin.from("doctor_email_logs").insert({
      doctor_id: input.doctorId,
      recipient_email: recipient,
      booking_id: input.bookingId,
      event_type: eventType,
      status: "failed",
      error_message: message,
    });

    throw error;
  }
}

// Lightweight test send used by the "Send test email" button in the Staff
// Portal. Bypasses the duplicate-status guard but still respects suppression.
export async function sendDoctorTestEmail(input: {
  doctorId: string;
  doctorName: string;
  recipientEmail: string;
}) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const recipient = input.recipientEmail.toLowerCase();

  const { data: suppressed } = await supabaseAdmin
    .from("suppressed_emails")
    .select("id")
    .eq("email", recipient)
    .maybeSingle();
  if (suppressed) {
    await supabaseAdmin.from("doctor_email_logs").insert({
      doctor_id: input.doctorId,
      recipient_email: recipient,
      event_type: "test_email",
      status: "suppressed",
    });
    return { sent: false, reason: "suppressed" as const };
  }

  const subject = "Test email — Harmony Elite Care";
  const html = `<!doctype html><html><body style="font-family:Arial,sans-serif;background:#fff;padding:24px;color:#0f172a"><h2 style="color:#0b2545">Test email</h2><p>Hello ${input.doctorName || "Doctor"},</p><p>This is a test message sent from the Harmony Elite Care Staff Portal to confirm that booking notification emails will reach this address.</p><p style="color:#64748b;font-size:12px">If you didn't expect this email, you can safely ignore it.</p></body></html>`;
  const text = `Test email\n\nHello ${input.doctorName || "Doctor"},\n\nThis is a test message from the Harmony Elite Care Staff Portal to confirm notification delivery.`;

  const messageId = crypto.randomUUID();
  await supabaseAdmin.from("email_send_log").insert({
    message_id: messageId,
    template_name: "doctor-test",
    recipient_email: recipient,
    status: "pending",
  });

  try {
    await sendViaGoogleMail({
      to: recipient,
      subject,
      html,
      text,
      replyTo: REPLY_TO,
    });

    await supabaseAdmin.from("email_send_log").insert({
      message_id: messageId,
      template_name: "doctor-test",
      recipient_email: recipient,
      status: "sent",
    });

    await supabaseAdmin.from("doctor_email_logs").insert({
      doctor_id: input.doctorId,
      recipient_email: recipient,
      event_type: "test_email",
      status: "sent",
      error_message: null,
    });

    return { sent: true };
  } catch (error) {
    const message = String(error instanceof Error ? error.message : error);
    await supabaseAdmin.from("email_send_log").insert({
      message_id: messageId,
      template_name: "doctor-test",
      recipient_email: recipient,
      status: "failed",
      error_message: message,
    });

    await supabaseAdmin.from("doctor_email_logs").insert({
      doctor_id: input.doctorId,
      recipient_email: recipient,
      event_type: "test_email",
      status: "failed",
      error_message: message,
    });

    throw new Error(message);
  }
}
