export function getPasswordChecks(password: string) {
  return {
    length: password.length >= 8,
    lower: /[a-z]/.test(password),
    upper: /[A-Z]/.test(password),
    number: /\d/.test(password),
    special: /[^A-Za-z0-9]/.test(password),
  };
}

export function getPasswordStrength(password: string) {
  const checks = getPasswordChecks(password);
  const score = Object.values(checks).filter(Boolean).length;

  if (!password) return { score: 0, label: "" };
  if (score <= 2) return { score, label: "Weak" };
  if (score === 3) return { score, label: "Fair" };
  if (score === 4) return { score, label: "Good" };
  return { score, label: "Strong" };
}

export function isStrongPassword(password: string) {
  const checks = getPasswordChecks(password);
  return checks.length && checks.lower && checks.upper && checks.number && checks.special;
}

export function getAuthErrorMessage(error: unknown) {
  const message =
    error instanceof Error
      ? error.message
      : typeof error === "string"
        ? error
        : "Something went wrong. Please try again.";

  const normalized = message.toLowerCase();

  if (normalized.includes("email not confirmed")) {
    return "Please verify your email before signing in.";
  }

  if (normalized.includes("invalid login credentials")) {
    return "Email or password is incorrect.";
  }

  if (normalized.includes("user already registered")) {
    return "This email is already registered. Sign in or resend the verification email.";
  }

  if (normalized.includes("password should be at least")) {
    return "Use a stronger password with at least 8 characters.";
  }

  if (normalized.includes("unable to validate email address") || normalized.includes("invalid email")) {
    return "Enter a valid email address.";
  }

  if (normalized.includes("rate limit")) {
    return "Too many attempts. Please wait a moment and try again.";
  }

  if (normalized.includes("signup is disabled")) {
    return "Account creation is currently unavailable.";
  }

  return message;
}