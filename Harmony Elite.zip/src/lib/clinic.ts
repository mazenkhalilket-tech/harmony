export const CLINIC = {
  name: "Harmony Physiotherapy Clinic",
  tagline: "Turn Your Pain Into Power",
  instagram: "https://www.instagram.com/harmony_physio.eg/",
  
  branches: [
    {
      id: "kazan",
      label: "Kazan Plaza — Fifth Settlement",
      address: "Kazan Plaza, Fifth Settlement, New Cairo",
      phone: "01500097369",
      phoneIntl: "+201500097369",
      whatsapp: "https://wa.me/201500097369",
      maps: "https://maps.app.goo.gl/DQ5mqiknM2XGrxQ26?g_st=ic",
      mapsEmbed: "https://www.google.com/maps?q=Kazan+Plaza+Fifth+Settlement+New+Cairo&output=embed",
    },
    {
      id: "sheikh-zayed",
      label: "Sheikh Zayed Branch",
      address: "Sheikh Zayed, Giza",
      phone: "01500773731",
      phoneIntl: "+201500773731",
      whatsapp: "https://wa.me/201500773731",
      maps: "https://maps.app.goo.gl/bFgF8WyTDtYy8MEH7?g_st=ic",
      mapsEmbed: "https://www.google.com/maps?q=Sheikh+Zayed+Cairo+Harmony+Physiotherapy&output=embed",
    },
  ],
} as const;

export type Branch = typeof CLINIC.branches[number];

export const SERVICES = [
  "Manual Therapy",
  "Lymphatic Massage",
  "Posture Correction Programs",
  "Recovery & Rehabilitation Programs",
  "Specialized Medical Assessment",
  "Spinal Column Treatment",
  "Sports Injury Rehabilitation",
] as const;

export const SLOTS = [
  "10:00",
  "11:00",
  "12:00",
  "14:00",
  "15:30",
  "17:00",
  "18:30",
  "20:00",
] as const;

export const BRANCH_IDS = CLINIC.branches.map((b) => b.id) as readonly string[];

